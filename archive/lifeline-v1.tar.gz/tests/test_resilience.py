"""Data handling, peer timing, and API shape for the resilience simulator."""

from fastapi.testclient import TestClient

from backend.app import app
from backend import engine
from backend.engine import aggregate, make_scenario, pfu_to_risk, risk_to_pfu, simulate
from backend.network import advisor_view, explain_migration, index_messages, plan_messages
from backend.orbit import LEAK, track
from backend.replay import make_replay, normalize_samples, run_replay


def test_gaps_stay_missing_and_flags_are_separate():
    parsed = normalize_samples(
        [
            {"t": "2024-05-10T00:00:00Z", "pfu": 12.5, "valid": 300, "dtc": 0, "oob": 0, "err": 4},
            {"t": "2024-05-10T00:05:00Z", "pfu": None, "valid": 0, "dtc": 0, "oob": 0, "err": 0},
            {"t": "2024-05-10T00:10:00Z", "pfu": 4.0, "valid": 12, "dtc": 0, "oob": 1, "err": 0},
        ]
    )
    assert parsed["measured"] == [12.5, None, 4.0]
    assert parsed["held"][1] == 12.5
    assert parsed["quality"] == ["ok", "gap", "degraded"]


def test_alert_is_invisible_before_delivery_and_loss_drops_it():
    observed = [{"A": 0.2, "B": 0.1, "C": 0.1} for _ in range(8)]
    confidence = [{"A": 0.92, "B": 0.92, "C": 0.92} for _ in range(8)]
    messages = plan_messages(observed, confidence, latency=3, loss=0, availability=1, seed=2)
    arrived = [item for item in index_messages(messages)["B"] if item["sender"] == "A" and item["deliverT"] <= 2]
    assert arrived == []
    visible = [item for item in index_messages(messages)["B"] if item["sender"] == "A" and item["deliverT"] <= 3]
    assert visible
    assert all(item["obsT"] <= item["deliverT"] for item in visible)

    lost = plan_messages(observed, confidence, latency=2, loss=1, availability=1, seed=2)
    assert lost
    assert all(item["status"] == "lost" for item in lost)
    assert index_messages(lost)["B"] == []


def test_stale_and_early_alerts_are_rejected():
    alert = {"sender": "B", "deliverT": 5, "expires": 9, "obsT": 5, "risk": 0.2}
    assert explain_migration(1, alert, 4, True)[0] is False
    ok, why = explain_migration(1, alert, 6, True)
    assert ok, why
    assert explain_migration(1, alert, 9, True)[1] == "alert is stale"
    future = {**alert, "obsT": 12}
    assert explain_migration(1, future, 6, True)[1] == "alert observation is in the future"
    assert explain_migration(0, alert, 6, True)[1] == "target has no free slot"


def test_advisor_view_has_no_future_sample():
    observed = [
        {"A": 0.1, "B": 0.1, "C": 0.1},
        {"A": 0.2, "B": 0.1, "C": 0.1},
        {"A": 0.95, "B": 0.1, "C": 0.1},
    ]
    view = advisor_view("A", 1, observed, [], [], "2024-05-10T00:05:00Z")
    assert view["recentLocalRisk"] == [0.1, 0.2]
    assert view["usesFuture"] is False
    assert "0.95" not in str(view["recentLocalRisk"])


def test_same_seed_replays_the_same_scores():
    first = simulate(make_scenario("spike", seed=4))
    second = simulate(make_scenario("spike", seed=4))
    assert first["summary"] == second["summary"]


def test_sharing_can_move_work_and_the_no_share_variant_cannot():
    result = simulate(make_scenario("sustained", seed=7))

    def received(name):
        return any(
            node["label"] == "Receiving jobs"
            for frame in result["frames"]
            for node in frame["controllers"][name]["nodes"]
        )

    assert received("adaptive")
    assert not received("local")
    assert result["summary"]["adaptive"]["useful"] > result["summary"]["local"]["useful"]


def test_gap_frame_does_not_publish_the_held_flux():
    scenario = make_replay("quiet2024", seed=1)
    scenario.measured[3] = None
    scenario.quality[3] = "gap"
    scenario.pfu[3] = scenario.pfu[2]
    result = simulate(scenario)
    frame = result["frames"][3]
    assert frame["gap"] is True
    assert frame["pfu"] is None
    assert frame["trace"]["confidence"]["A"] == 0.0


def test_may_frames_only_expose_delivered_alerts():
    result = run_replay(make_replay("may2024", seed=7))
    assert result["replay"]["satellite"] == "GOES-18"
    assert result["advisorCalls"] == 0
    assert "local" in result["summary"]
    saw_delivery = False
    for frame in result["frames"]:
        for item in frame["trace"]["deliveries"]:
            if item["sender"] == "A" and item["receiver"] == "B":
                saw_delivery = True
            assert item["deliverT"] == frame["t"]
            assert item["obsT"] <= frame["t"]
        for item in frame["trace"]["inbox"]["B"]:
            assert item["deliverT"] <= frame["t"] < item["expires"]
            assert item["obsT"] <= item["deliverT"]
    assert saw_delivery


def test_api_lists_events_and_returns_trace_frames():
    client = TestClient(app)
    listed = client.get("/api/events")
    assert listed.status_code == 200
    payload = listed.json()
    assert [item["id"] for item in payload["events"]] == [
        "mar2024",
        "may2024",
        "jun2024",
        "oct2024",
        "jan2026",
    ]
    assert payload["events"][1]["units"]
    assert payload["control"]["id"] == "quiet2024"
    run = client.post("/api/run", json={"source": "scripted", "preset": "spike", "use_grok": False, "seed": 2})
    assert run.status_code == 200
    body = run.json()
    assert body["advisorCalls"] == 0
    assert set(body["summary"]) >= {"ground", "threshold", "adaptive", "local"}
    frame = body["frames"][10]
    assert "observed" in frame
    assert "inbox" in frame["trace"]
    assert "proposed" in frame["trace"]
    assert "executed" in frame["trace"]


def test_risk_scale_round_trips():
    for pfu in (3.0, 10.0, 55.0, 100.0, 1000.0, 42000.0):
        assert abs(risk_to_pfu(pfu_to_risk(pfu)) - pfu) / pfu < 1e-6


def test_polar_orbit_crosses_caps_and_low_orbit_stays_shielded():
    rows = track(288, 5)
    polar = [row["A"]["exposure"] for row in rows]
    low = [row["C"]["exposure"] for row in rows]
    assert max(polar) == 1.0
    assert 0.2 < sum(value > 0.5 for value in polar) / len(polar) < 0.45
    assert max(low) <= LEAK + 1e-9


def test_decisions_do_not_depend_on_future_flux():
    base = make_replay("oct2024", seed=3)
    cut = 700
    altered = make_replay("oct2024", seed=3)
    altered.pfu = altered.pfu[:cut] + [value * 50 for value in altered.pfu[cut:]]
    first = simulate(base)["frames"]
    second = simulate(altered)["frames"]
    for t in range(cut):
        for name in ("adaptive", "local", "threshold", "ground"):
            assert first[t]["controllers"][name]["nodes"] == second[t]["controllers"][name]["nodes"], (t, name)


def test_planned_holds_lose_no_unsaved_work():
    lost_on_hold = []
    original = engine._enter_hold

    def spy(world, node, planned):
        if planned:
            lost_on_hold.append(sum(job.unsaved for job in engine._hosted(world, node.id)))
        original(world, node, planned)

    engine._enter_hold = spy
    try:
        simulate(make_replay("oct2024", seed=2))
    finally:
        engine._enter_hold = original
    assert lost_on_hold
    assert max(lost_on_hold) < 1e-6


def test_cooperative_beats_both_baselines_on_a_real_storm():
    results = [simulate(make_replay("oct2024", seed=seed)) for seed in (1, 2, 3)]
    scores = aggregate(results)
    adaptive = scores["adaptive"]
    for base in ("ground", "threshold"):
        assert adaptive["missed"] < scores[base]["missed"]
        assert adaptive["lost"] < scores[base]["lost"]
        assert adaptive["downtime"] < scores[base]["downtime"]
    assert adaptive["interlocks"] == 0
    assert adaptive["missed"] < scores["local"]["missed"]


def test_quiet_control_is_identical_across_controllers():
    summary = simulate(make_replay("quiet2024", seed=1))["summary"]
    assert summary["adaptive"]["useful"] == summary["threshold"]["useful"] == summary["ground"]["useful"]
    assert summary["adaptive"]["migrations"] == 0


def test_evaluate_reports_a_headline():
    client = TestClient(app)
    body = client.post("/api/evaluate", json={"source": "scripted"}).json()
    assert {"totals", "change"} <= set(body["headline"])
    assert body["rows"][0]["controllers"]["adaptive"]["downtime"] >= 0


def test_debrief_facts_come_from_the_run(monkeypatch):
    from backend import app as app_module

    captured = {}

    def fake(facts):
        captured.update(facts)
        return {"text": "ok", "provider": "grok", "model": "test", "latencyMs": 1.0}

    monkeypatch.setattr(app_module, "debrief", fake)
    monkeypatch.setenv("XAI_API_KEY", "test")
    body = TestClient(app).post("/api/debrief", json={"source": "noaa", "preset": "oct2024"}).json()
    assert body["text"] == "ok"
    run = run_replay(make_replay("oct2024", seed=7))
    adaptive = captured["scores"]["Cooperative adaptive"]
    assert adaptive["missedServiceDeadlines"] == run["summary"]["adaptive"]["missed"]
    assert captured["events"]["serviceMoves"]


def test_debrief_without_key_does_not_call_a_model(monkeypatch):
    monkeypatch.delenv("XAI_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    body = TestClient(app).post("/api/debrief", json={"source": "scripted", "preset": "spike"}).json()
    assert body["text"] is None


def test_emergency_comms_is_scheduled_before_other_work():
    world = engine.initial_world(make_replay("quiet2024", seed=1))
    for job in world.jobs:
        job.node = "C"
        engine._release_and_expire(job, 0)
        engine._release_and_expire(job, job.offset)
    ordered = sorted([job for job in world.jobs if job.node == "C"], key=engine._priority)
    assert ordered[0].name == "Emergency comms"
    assert all(job.priority == "best-effort" for job in ordered[-3:])


def test_milton_week_keeps_emergency_comms_on_time():
    results = [simulate(make_replay("oct2024", seed=seed)) for seed in (1, 2, 3)]
    scores = aggregate(results)
    for base in ("ground", "threshold"):
        assert scores["adaptive"]["criticalMissed"] <= scores[base]["criticalMissed"]
    assert scores["adaptive"]["criticalMissed"] < scores["threshold"]["criticalMissed"]


def test_default_run_is_the_milton_mission():
    body = TestClient(app).post("/api/run", json={}).json()
    assert body["preset"] == "oct2024"
    assert "Milton" in body["mission"]["headline"]
    assert "simulated" in body["mission"]["whatIf"]
    assert {item["name"] for item in body["services"]} >= {"Emergency comms", "Imagery", "Flood maps"}
