# Lifeline

**Keeping disaster-response satellites working through solar storms.**

When a hurricane hits, responders lean on satellites for storm imagery, emergency communications, and flood maps. Sometimes the Sun strikes the same week. Lifeline is a prototype in which a small constellation of disaster-response satellites warn each other about incoming radiation, protect the most critical service first, and keep it running without waiting for the ground. It replays real NOAA radiation measurements and compares that cooperative approach with ground-dependent and isolated fixed-threshold protection.

## The scenario: storm on storm

Hurricane Milton made landfall near Siesta Key, Florida, at about 8:30 pm EDT on 9 October 2024 ([NHC report](https://www.nhc.noaa.gov/data/tcr/AL142024_Milton.pdf)). That morning, an X1.8 solar flare erupted at 01:56 UTC. Proton flux crossed the S1 radiation-storm threshold around 04:40 UTC, and NOAA issued a rare G4 severe geomagnetic storm watch for 10–11 October ([SWPC](https://www.swpc.noaa.gov/news/g4-severe-storm-watch-10-11-october)). In the GOES-18 replay the proton peak lands at 15:15 UTC on 10 October, the first day of the recovery.

Three simulated satellites carry the services responders would need:

| Satellite | Orbit | Service | Priority |
|---|---|---|---|
| B | 53°, broadband-constellation style | Emergency comms relay: short tasks every hour, tight deadlines | Critical |
| A | Polar 97.4°, typical for Earth imaging | Hurricane imagery downlink | Essential |
| C | 30°, shielded by Earth's magnetic field | Flood-mapping inference | Essential |
| All | | Science archive processing | Best-effort |

The other windows add context: the May 2024 Gannon storm (the strongest geomagnetic storm since 2003), S2/S3 storms in March and June 2024, the January 2026 S4 storm (the strongest radiation storm in more than 20 years) as a stress test, and a quiet July 2024 control.

**This is a what-if simulation.** Real events set the dates and the measured radiation; the satellites, services, faults, and outcomes are simulated. Nothing here claims that real satellites failed or succeeded during these events.

## Run

```bash
.venv/bin/uvicorn backend.app:app --host 127.0.0.1 --port 8010
```

Open http://127.0.0.1:8010/#dashboard . The Hurricane Milton week (October 2024) is the default. Scripted scenarios remain available from the Source control. Ask Grok and the Grok mission debrief need `XAI_API_KEY` in `.env`; batch evaluation never calls a model.

```bash
.venv/bin/python -m pytest tests
```

## Results

Five seeds per window, default settings, summed over the five NOAA storm windows (quiet control excluded). Reproduce with `POST /api/evaluate` or the "Across scenarios" panel.

| | Ground-dependent | Fixed-threshold | Cooperative, no sharing | **Cooperative (Lifeline)** |
|---|---|---|---|---|
| Emergency comms deadlines missed | 21.8 | 21.2 | 8.2 | **3.0** |
| All service deadlines missed | 66.0 | 78.8 | 46.6 | **11.8** |
| Lost computation (work units) | 78.3 | 59.8 | 34.7 | **29.5** |
| Responder-facing downtime (5-min steps) | 1,330 | 1,467 | 986 | **252** |
| Hardware interlocks | 15 | 8 | 0 | **0** |

Against the fixed threshold that is 86% fewer missed emergency-comms deadlines, 85% fewer missed deadlines overall, 51% less lost work, and 83% less downtime. The no-sharing column runs the same policy with alerts switched off, so the gap between it and Lifeline is the value of satellites warning each other.

**Milton week alone** (October 2024, per run): Lifeline missed 0.0 emergency-comms deadlines, against 8.0 for fixed-threshold, 5.2 for ground-dependent, and 1.8 without sharing. Responder-facing downtime was about 5.6 hours, against 38 hours for fixed-threshold.

**Where it does not help.** In May 2024 (peak 404 pfu) every strategy does well, and Lifeline misses slightly more imagery and flood-map deliveries (1.6 against 0.2 per run) because of the extra moves, though its downtime is lower. In the scripted cluster-wide hazard every satellite is hot, no peer qualifies as a safe harbor, and Lifeline matches the isolated policies. In January 2026 even the shielded satellite gets hot, so its mean time to restore is slightly longer than the threshold's (12 against 9.9 steps), though total downtime is still 71% lower.

## How it works

**Exposure differs by orbit.** GOES-18 sits outside the magnetosphere, so its flux stands for the interplanetary level. In low Earth orbit, solar protons reach mainly the polar caps; near the equator the geomagnetic field shields the orbit. [orbit.py](backend/orbit.py) places the three satellites in circular orbits (A polar at 97.4°, B at 53°, C at 30°) and scales the shared flux by a tilted-dipole exposure factor: 1 above 63° magnetic latitude, 0.4% below 55°. A crosses a cap for 15–20 minutes twice per orbit. B clips the cap on some passes. C stays shielded except in the largest events.

**Each node fuses two local sources.** The particle sensor (with seeded noise and the archive's quality flags as confidence) and a correctable-memory-error count whose rate rises with true risk. When the sensor has a data gap, the error telemetry keeps the estimate alive.

**Workload.** Each satellite hosts one service (see the scenario table) that releases a task every period, due one period later, and one best-effort archive job that soaks up spare capacity. The critical emergency-comms relay releases half-size tasks twice as often, so its deadlines are tighter. Scheduling is by priority (critical, then essential, then best-effort) and earliest deadline first within a priority. Services are moved and returned in priority order. A completed task commits its result; otherwise progress is safe only after a checkpoint.

**Faults.** While a payload is active (computing or checkpointing), each step has hit probability `risk² × k`, and the first time true risk reaches 0.62 there is one scripted rollback. A hit loses unsaved progress. Entering safe-hold powers the payload down, so unsaved progress is lost unless it was checkpointed first. A hardware interlock forces safe-hold at true risk 0.72, which no controller can override.

**Four controllers, one environment.** All four worlds share the hazard trace, sensor noise, telemetry draw, peer-message schedule, and fault draw.

| Controller | Uses | Protective behavior |
|---|---|---|
| Ground-dependent | Each node's sensor reading, 12 steps late, only while the ground link is up | Cautious, checkpoint then hold, resume. Interlocked nodes wait for a ground command. |
| Fixed-threshold | Its own sensor reading | Cautious at 0.35, checkpoint then hold at 0.55, resume after a fixed quiet streak |
| Cooperative, no sharing | Fused local reading, own planned orbit | Checkpoints and holds before a forecast cap crossing, resumes when the orbit leaves the cap. No migration. |
| Cooperative adaptive | The above plus peer alerts delivered by this step | Moves an essential service to a peer forecast to stay below 0.35 for the next orbit, sheds that peer's best-effort work to make room, and returns the service home after the all-clear |

Forecasts come from planned orbits, which a spacecraft knows, times an ambient-flux estimate taken only from readings inside a cap (its own recent ones, or a peer's). Controllers never see true risk or any later sample; `test_decisions_do_not_depend_on_future_flux` checks this by altering the flux after step 700 and comparing every earlier frame.

**Peer messages.** A message carries the sender, observation step, delivery step, expiry, fused reading, trend, confidence, planned exposure, and, when the sender is inside a cap, its ambient estimate. A migration is rejected when the target's message is missing, not yet delivered, stale, or too hot, when the target is forecast to be exposed, or when the target lacks service capacity.

**Metrics.** Missed deadlines are service tasks not finished by their deadline. Lost computation is unsaved progress destroyed by faults or power-down. Downtime counts essential-service steps not running on an active node. Mean time to restore is the average length of those interruptions. Active steps at risk ≥ 0.45 count how often a payload stayed active at high true risk.

**Advisor.** Ask Grok calls a remote API at most three times per run, after a threshold crossing or a newly delivered hazard alert. It emulates onboard advice and is not an onboard computer. The request contains the deciding node's current and past fused reading, its planned exposure ahead, alerts already delivered, jobs, and the permitted actions. Every proposal passes the same local validation, and the interlock still applies.

**Mission debrief.** The dashboard's "Write with Grok" button sends the finished run's scores, service moves, planned-hold counts, and event metadata to the model and shows a short operator report. The model is told to quote only those numbers, and the report is labeled as model-written. The simulator scores are unchanged.

**Model keys.** Put `XAI_API_KEY` in `.env` (gitignored; see `.env.example`). `XAI_MODEL` defaults to `grok-4`. `OPENAI_API_KEY` is the fallback. Requests use the `certifi` CA bundle, so Homebrew Python works without system certificates.

## API

`POST /api/run` returns one request-local simulation, with every frame. `POST /api/debrief` takes the same body and returns a model-written report plus the facts it was given. `POST /api/evaluate` returns five-seed averages per scenario and a `headline` block with totals and percentage changes. `GET /api/events` lists the five NOAA windows plus the July 2024 quiet control.

Each step is one sample. NOAA replays use the archive cadence of five minutes. Scripted scenarios use one simulated second per step. Deadlines and durations are in steps; playback speed does not change them.

## Data provenance

The fixtures in `data/noaa/` come from NOAA NCEI GOES-18 `sgps-l2-avg5m` files (version 3-0-2, January 2026 uses 3-0-3). Rebuild them with `scripts/extract_noaa.py` when the NetCDF cache is present. The running server reads the JSON only.

`AvgIntProtonFlux` in those files is the P11 channel above 500 MeV. It is not the ≥10 MeV integral used for the NOAA S scale, so the replay does not use it. Each sample is the westward-looking `AvgDiffProtonFlux` (the −X direction when `yaw_flip_flag` is 0), summed over channel widths at and above 10 MeV. The bin that straddles 10 MeV contributes only the fraction above 10 MeV. Units are protons/(cm² sr s). This is a channel sum, not the SWPC integral product.

Timestamps are the file `time` variable, seconds since 2000-01-01 12:00:00 UTC, at a five-minute cadence. Quality flags kept per sample are `DiffValidL1bSamplesInAvg`, dead-time (`DiffDQFdtcSum`), out-of-band (`DiffDQFoobSum`), and dynamic error (`DiffDQFerrSum`). A missing flux stays missing. Dead-time, out-of-band, or fewer than 30 valid seconds marks the sample degraded. Dynamic error is shown in the catalog check and does not by itself reject the sample. During a gap the environment model holds the previous value for fault timing only; the frame reports the flux as missing and the sensor confidence as 0.

Catalog peaks below are NOAA's event catalog, compared with the extracted channel sum. Peak times match. Magnitudes do not always match, and the simulator follows the channel sum.

| Window | Catalog | Channel sum |
|---|---|---|
| 2024-03-23 18:20 UTC | 956 pfu, S2 | 1,006 pfu |
| 2024-05-10 17:45 UTC | 208 pfu, S2 | 404 pfu |
| 2024-05-11 09:10 UTC | 116 pfu, S2 | 109 pfu |
| 2024-06-08 08:00 UTC | 1,030 pfu, S3 | 996 pfu |
| 2024-10-10 15:15 UTC | 1,810 pfu, S3 | 2,932 pfu |
| 2026-01-19 19:15 UTC | 37,000 pfu, S4 | 42,201 pfu |

The quiet control, 18–22 July 2024, peaks at 0.54 pfu, below the S1 threshold of 10 pfu.

Sources: [GOES-R space environment in-situ](https://www.ncei.noaa.gov/products/goes-r-space-environment-in-situ), the [NCEI space-weather portal API](https://www.ncei.noaa.gov/cloud-access/space-weather-portal/api/v1/openapi/), and the [NOAA solar proton event list](https://www.ngdc.noaa.gov/stp/space-weather/interplanetary-data/solar-proton-events/SEP%20page%20code.html).

## Measured versus simulated

Measured: the shared GOES-18 channel-sum series, its timestamps, and its quality flags.

Simulated, and labeled as such: orbits and the geomagnetic exposure factor, per-node sensor noise (standard deviation 0.04 on the 0–1 risk scale for NOAA replays), correctable-error telemetry, hardware faults, workloads, checkpoints, peer-link delay and loss, and the mapping from flux to risk. That mapping is a simulator scale, not a NOAA product: 10 pfu stays below cautious, 100 pfu meets safe-hold, and 1,000 pfu meets the safety limit.

The exposure model is a schematic tilted dipole with a fixed cutoff band. It ignores rigidity cutoffs, their storm-time suppression, the South Atlantic Anomaly, and orbital precession. Faults are an assumption, not spacecraft telemetry. Space-weather forecasts are not an input; a later version could give the ground controller a warning that existed at its issue time.
