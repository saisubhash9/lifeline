"""Schematic LEO geometry and solar-particle exposure for the three satellites.

Solar energetic protons reach low Earth orbit mainly over the polar caps, where
the geomagnetic field lines open to interplanetary space. Near the equator the
field shields the orbit. This module turns each satellite's position into an
exposure factor between LEAK and 1 that scales the shared GOES flux.

The model is a tilted dipole with a fixed cutoff latitude band. It does not
compute rigidity cutoffs, storm-time cutoff suppression, or the South Atlantic
Anomaly. Orbits are circular and ignore precession and drag.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

POLE_LAT = math.radians(80.7)
POLE_LON = math.radians(-72.7)
SIDEREAL_MIN = 1436.07
CUTOFF_LOW = 55.0
CUTOFF_HIGH = 63.0
LEAK = 0.004
SUBSAMPLES = 10


@dataclass(frozen=True)
class Orbit:
    label: str
    inclination: float
    period_min: float
    raan: float
    phase: float


ORBITS = {
    "A": Orbit("Polar, 97.4°", 97.4, 94.6, 0.0, 0.0),
    "B": Orbit("Mid-inclination, 53°", 53.0, 95.4, 120.0, 0.35),
    "C": Orbit("Low-inclination, 30°", 30.0, 96.1, 240.0, 0.7),
}


def position(orbit: Orbit, minutes: float) -> tuple[float, float]:
    """Geographic latitude and longitude in degrees for a circular orbit."""
    inc = math.radians(orbit.inclination)
    u = 2 * math.pi * (minutes / orbit.period_min + orbit.phase)
    lat = math.asin(math.sin(inc) * math.sin(u))
    lon = math.radians(orbit.raan) + math.atan2(math.cos(inc) * math.sin(u), math.cos(u))
    lon -= 2 * math.pi * minutes / SIDEREAL_MIN
    lon = (lon + math.pi) % (2 * math.pi) - math.pi
    return math.degrees(lat), math.degrees(lon)


def magnetic_latitude(lat: float, lon: float) -> float:
    phi, lam = math.radians(lat), math.radians(lon)
    value = math.sin(phi) * math.sin(POLE_LAT) + math.cos(phi) * math.cos(POLE_LAT) * math.cos(lam - POLE_LON)
    return math.degrees(math.asin(max(-1.0, min(1.0, value))))


def exposure_at(lat: float, lon: float) -> float:
    mlat = abs(magnetic_latitude(lat, lon))
    if mlat <= CUTOFF_LOW:
        return LEAK
    if mlat >= CUTOFF_HIGH:
        return 1.0
    span = (mlat - CUTOFF_LOW) / (CUTOFF_HIGH - CUTOFF_LOW)
    return LEAK + span * (1.0 - LEAK)


def track(ticks: int, step_minutes: float) -> list[dict[str, dict[str, float]]]:
    """Per step: position at the step start and exposure averaged across the step."""
    rows = []
    for t in range(ticks):
        row = {}
        for node, orbit in ORBITS.items():
            start = t * step_minutes
            total = 0.0
            for k in range(SUBSAMPLES):
                lat, lon = position(orbit, start + step_minutes * (k + 0.5) / SUBSAMPLES)
                total += exposure_at(lat, lon)
            lat, lon = position(orbit, start)
            row[node] = {"lat": round(lat, 1), "lon": round(lon, 1), "exposure": round(total / SUBSAMPLES, 3)}
        rows.append(row)
    return rows
