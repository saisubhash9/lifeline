"""Peer-link messages for the three-satellite cluster.

A node may use a peer's risk only after that message's delivery step and before
it expires. Hidden environmental truth and future samples are not inputs.
"""

from __future__ import annotations

import random

NODES = ("A", "B", "C")
BEACON_EVERY = 6
ALERT_HOLD = 8
EXPOSE_LIMIT = 0.45


def plan_messages(
    observed: list[dict[str, float]],
    confidence: list[dict[str, float]],
    *,
    latency: int,
    loss: float,
    availability: float,
    seed: int,
    exposure: list[dict[str, float]] | None = None,
    ambient: list[dict[str, float | None]] | None = None,
    hold: int = ALERT_HOLD,
    beacon_every: int = BEACON_EVERY,
) -> list[dict]:
    """Schedule beacons and hazard alerts. Delivery is never earlier than send + latency.

    A message carries the sender's fused reading, its exposure from the planned
    orbit, and, when the sender is inside a polar cap, its ambient-flux estimate.
    """
    rng = random.Random(seed + 1009)
    latency = max(1, int(latency))
    loss = min(1.0, max(0.0, float(loss)))
    availability = min(1.0, max(0.0, float(availability)))
    messages: list[dict] = []
    last_sent: dict[str, float | None] = {node: None for node in NODES}
    last_ambient: dict[str, float | None] = {node: None for node in NODES}
    number = 1
    for t, row in enumerate(observed):
        for sender in NODES:
            risk = row[sender]
            previous = last_sent[sender]
            seen = ambient[t][sender] if ambient else None
            extra = {
                "exposure": round(exposure[t][sender], 3) if exposure else None,
                "ambient": seen,
                "trend": _trend(observed, sender, t),
            }
            hazard = risk >= 0.35 and (previous is None or abs(risk - previous) >= 0.05)
            news = seen is not None and seen >= 0.35 and (
                last_ambient[sender] is None or abs(seen - last_ambient[sender]) >= 0.05
            )
            beacon = t % beacon_every == 0
            if not hazard and not news and not beacon:
                continue
            kind = "alert" if hazard or news else "beacon"
            for receiver in NODES:
                if receiver == sender:
                    continue
                link_up = availability >= 1 or rng.random() < availability
                if not link_up:
                    messages.append(
                        _message(number, sender, receiver, t, risk, confidence[t][sender], kind, "dropped", None, t, extra)
                    )
                    number += 1
                    continue
                if rng.random() < loss:
                    messages.append(
                        _message(number, sender, receiver, t, risk, confidence[t][sender], kind, "lost", None, t, extra)
                    )
                    number += 1
                    continue
                deliver = t + latency
                messages.append(
                    _message(
                        number,
                        sender,
                        receiver,
                        t,
                        risk,
                        confidence[t][sender],
                        kind,
                        "sent",
                        deliver,
                        deliver + hold,
                        extra,
                    )
                )
                number += 1
            last_sent[sender] = risk
            if seen is not None:
                last_ambient[sender] = seen
    return messages


def _trend(rows: list[dict[str, float]], node: str, t: int) -> float:
    """Smoothed slope per step over the sender's last six readings."""
    recent = [rows[step][node] for step in range(max(0, t - 2), t + 1)]
    earlier = [rows[step][node] for step in range(max(0, t - 5), max(0, t - 2) + 1)]
    gap = max(1, (len(recent) + len(earlier)) / 2)
    return round((sum(recent) / len(recent) - sum(earlier) / len(earlier)) / gap, 4)


def _message(number, sender, receiver, t, risk, confidence, kind, status, deliver, expires, extra=None) -> dict:
    return {
        **(extra or {}),
        "id": number,
        "sender": sender,
        "receiver": receiver,
        "obsT": t,
        "sendT": t,
        "deliverT": deliver,
        "risk": round(float(risk), 3),
        "confidence": round(float(confidence), 2),
        "expires": expires,
        "status": status,
        "kind": kind,
    }


def index_messages(messages: list[dict]) -> dict[str, list[dict]]:
    grouped = {node: [] for node in NODES}
    for message in messages:
        if message["status"] != "sent" or message["deliverT"] is None:
            continue
        grouped[message["receiver"]].append(message)
    for node in NODES:
        grouped[node].sort(key=lambda item: (item["deliverT"], item["id"]))
    return grouped


def explain_migration(free_slots: int, alert: dict | None, t: int, has_essential: bool) -> tuple[bool, str]:
    """Decide whether a workload move is allowed from information delivered by step t."""
    if not has_essential:
        return False, "no essential workload on the source"
    if alert is None:
        return False, "no delivered alert from the target"
    if alert["deliverT"] is None or alert["deliverT"] > t:
        return False, "alert is not delivered yet"
    if alert["obsT"] > t:
        return False, "alert observation is in the future"
    if alert["expires"] <= t:
        return False, "alert is stale"
    if alert["risk"] > EXPOSE_LIMIT:
        return False, "target is too exposed"
    if free_slots < 1:
        return False, "target has no free slot"
    return True, "Peer alert is fresh, the target has spare service capacity, and its reported risk is at or below 0.45."


def advisor_view(
    node: str,
    t: int,
    observed: list[dict[str, float]],
    inbox: list[dict],
    jobs: list[dict],
    utc: str | None,
    exposure_ahead: list[float] | None = None,
) -> dict:
    """State the deciding node can know. Later rows of `observed` are not copied."""
    history = [round(row[node], 3) for row in observed[: t + 1]][-8:]
    alerts = [
        {
            "sender": item["sender"],
            "obsT": item["obsT"],
            "deliverT": item["deliverT"],
            "expires": item["expires"],
            "risk": item["risk"],
            "confidence": item["confidence"],
            "kind": item["kind"],
            "ambient": item.get("ambient"),
        }
        for item in inbox
        if item["receiver"] == node and item["deliverT"] is not None and item["deliverT"] <= t < item["expires"]
    ]
    return {
        "t": t,
        "utc": utc,
        "node": node,
        "localRisk": round(observed[t][node], 3),
        "recentLocalRisk": history,
        "deliveredAlerts": alerts,
        "jobs": jobs,
        "plannedExposureAhead": exposure_ahead,
        "reachable": sorted({item["sender"] for item in alerts}),
        "permittedActions": ["hold", "cautious", "checkpoint", "safe-hold", "migrate", "resume"],
        "usesFuture": False,
        "emulation": (
            "This remote API call emulates onboard advice. It receives only this node's "
            "current and past local telemetry, its planned orbit exposure, alerts already "
            "delivered, and permitted actions."
        ),
    }
