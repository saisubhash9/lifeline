"""GOES-18 five-minute proton replays extracted from NCEI sgps-l2-avg5m files."""

from __future__ import annotations

import json
from pathlib import Path

from backend.engine import REPLAY_TIMING, Scenario, aggregate, pfu_to_risk, simulate

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "noaa"
ORDER = ["mar2024", "may2024", "jun2024", "oct2024", "jan2026", "quiet2024"]
STEP_MINUTES = 5

NOTE = (
    "Replay of a GOES-18 five-minute series. AvgIntProtonFlux in the archive is the "
    ">500 MeV channel, so it is not used. The curve is the westward differential-channel "
    "sum at and above 10 MeV, in protons per square centimeter per steradian per second. "
    "Catalog peaks are a separate check, not the simulated input. GOES sits outside the "
    "magnetosphere, so its flux stands for the interplanetary level. Each satellite's "
    "exposure scales that flux by a schematic geomagnetic-shielding factor from its planned "
    "orbit: full over the polar caps, about 0.4% near the equator. Local readings add seeded "
    "sensor noise and simulated hardware-error telemetry. Peer alerts arrive after the "
    "configured latency. The 0–1 risk score is a simulator scale: 100 pfu meets safe-hold "
    "and 1,000 pfu meets the safety limit. Faults are simulated. Ground delay is 12 steps "
    "(60 minutes). Space-weather forecasts are not an input; orbits are."
)

SOURCE_URL = "https://www.ncei.noaa.gov/products/goes-r-space-environment-in-situ"
CATALOG_URL = (
    "https://www.ngdc.noaa.gov/stp/space-weather/interplanetary-data/"
    "solar-proton-events/SEP%20page%20code.html"
)
UNITS = "protons/(cm^2 sr s), westward differential-channel sum at and above 10 MeV"
SENSOR_NOISE = 0.04


WHAT_IF = (
    "What-if simulation. Real events set the dates and the measured radiation; the "
    "satellites, services, faults, and outcomes are simulated. Nothing here claims that "
    "real satellites failed or succeeded during these events."
)

MISSIONS = {
    "oct2024": {
        "headline": "Hurricane Milton meets a solar storm",
        "context": (
            "Milton made landfall south of Tampa on the evening of 9 October 2024. That same "
            "morning an X1.8 solar flare launched a proton storm and a fast coronal mass "
            "ejection. The satellites responders would lean on for storm imagery, emergency "
            "communications, and flood maps face the radiation during the first days of "
            "the recovery."
        ),
        "timeline": [
            ["2024-10-09T01:56:00Z", "X1.8 solar flare erupts"],
            ["2024-10-09T04:40:00Z", "Proton flux crosses the S1 radiation-storm threshold"],
            ["2024-10-10T00:00:00Z", "G4 severe geomagnetic storm watch begins (10–11 Oct)"],
            ["2024-10-10T00:30:00Z", "Milton makes landfall near Siesta Key, Florida (8:30 pm EDT on 9 Oct)"],
            ["2024-10-10T15:15:00Z", "Replay proton peak, S3 in the NOAA catalog"],
        ],
        "sources": [
            ["NOAA SWPC G4 watch", "https://www.swpc.noaa.gov/news/g4-severe-storm-watch-10-11-october"],
            ["NHC Milton report", "https://www.nhc.noaa.gov/data/tcr/AL142024_Milton.pdf"],
            ["Radiation storm in progress", "https://watchers.news/2024/10/09/strong-solar-radiation-in-progress-severe-geomagnetic-storm-watch-in-effect/"],
        ],
        "hero": True,
    },
    "may2024": {
        "headline": "The Gannon storm",
        "context": (
            "May 2024 brought the strongest geomagnetic storm since 2003 (G5). Its proton "
            "storm was moderate, two S2 peaks, which tests whether satellites resume too soon "
            "between waves."
        ),
        "sources": [["May 2024 solar storms", "https://en.wikipedia.org/wiki/May_2024_solar_storms"]],
    },
    "jan2026": {
        "headline": "Strongest radiation storm in over 20 years",
        "context": (
            "On 19 January 2026 NOAA reported an S4 (severe) solar radiation storm. Here even "
            "the best-shielded satellite is exposed, so there is little safe room to move "
            "services to. This is the stress test."
        ),
        "sources": [["NOAA SWPC S4 notice", "https://www.spaceweather.gov/news/s4-severe-solar-radiation-storm-progress-january-19th-2026"]],
    },
    "mar2024": {
        "headline": "Routine operations under an S2 storm",
        "context": "A radiation storm near the S3 threshold on an otherwise ordinary day for response services.",
    },
    "jun2024": {
        "headline": "Routine operations under an S3 storm",
        "context": "A sharper rise into S3. Tests how fast protection starts.",
    },
    "quiet2024": {
        "headline": "Quiet control",
        "context": "No radiation storm. A good policy should behave exactly like the others here.",
    },
}


def mission(window_id: str) -> dict:
    return {"whatIf": WHAT_IF, "timeline": [], "sources": [], "hero": False, **MISSIONS.get(window_id, {})}


def _records() -> dict[str, dict]:
    found = {}
    for path in DATA.glob("*.json"):
        if path.name == "manifest.json":
            continue
        record = json.loads(path.read_text())
        found[record["id"]] = record
    return found


WINDOWS = _records()


def window_ids() -> list[str]:
    return [name for name in ORDER if name in WINDOWS]


def describe(window_id: str) -> dict:
    record = WINDOWS[window_id]
    catalog = []
    for item in record["catalog"]:
        sample = next((row for row in record["samples"] if row["t"] == item.get("extractedUtc")), None)
        flags = {}
        if sample:
            flags = {
                "valid": sample.get("valid", 0),
                "dtc": sample.get("dtc", 0),
                "oob": sample.get("oob", 0),
                "err": sample.get("err", 0),
            }
        catalog.append({**item, **flags})
    return {
        "id": record["id"],
        "label": record["label"],
        "why": record["why"],
        "start": record["start"],
        "end": record["end"],
        "defaultOutageHours": record["defaultOutageHours"],
        "peakUtc": record["peakUtc"],
        "peakPfu": record["peakPfu"],
        "maxPfu": record["maxPfu"],
        "catalog": catalog,
        "method": record["method"],
        "product": record["product"],
        "satellite": record["satellite"],
        "files": record["files"],
        "units": UNITS,
        "cadenceMinutes": STEP_MINUTES,
        "sourceUrl": SOURCE_URL,
        "catalogUrl": CATALOG_URL,
        "mission": mission(record["id"]),
    }


def normalize_samples(samples: list[dict]) -> dict:
    """Preserve gaps as missing measurements. Held values continue the environment model only."""
    measured: list[float | None] = []
    held: list[float] = []
    quality: list[str] = []
    utc: list[str] = []
    last = 0.0
    for sample in samples:
        utc.append(sample["t"])
        raw = sample.get("pfu")
        if raw is None:
            measured.append(None)
            held.append(last)
            quality.append("gap")
            continue
        value = float(raw)
        last = value
        measured.append(value)
        held.append(value)
        if sample.get("dtc") or sample.get("oob") or int(sample.get("valid") or 0) < 30:
            quality.append("degraded")
        else:
            quality.append("ok")
    return {"utc": utc, "measured": measured, "held": held, "quality": quality}


def make_replay(
    window_id: str = "may2024",
    outage_hours: int | None = None,
    bandwidth: float = 3.0,
    seed: int = 7,
    peer_latency: int = 2,
    peer_loss: float = 0.0,
    peer_availability: float = 1.0,
) -> Scenario:
    record = WINDOWS.get(window_id) or WINDOWS["may2024"]
    series = normalize_samples(record["samples"])
    pfu = series["held"]
    utc = series["utc"]
    quality = series["quality"]
    ticks = len(pfu)
    peak = max(range(ticks), key=lambda index: pfu[index])
    hours = record["defaultOutageHours"] if outage_hours is None else max(0, int(outage_hours))
    duration = hours * (60 // STEP_MINUTES)
    if duration <= 0:
        outage_start, outage_end = -1, -1
    else:
        outage_start = peak - duration // 2
        outage_end = outage_start + duration
    hot = [index for index, value in enumerate(series["measured"]) if value is not None and value >= 10]
    if hot:
        hazard_start, hazard_end = hot[0], hot[-1] + 1
    else:
        hazard_start, hazard_end = ticks, ticks
    peak_risk = pfu_to_risk(pfu[peak])
    return Scenario(
        name=record["id"],
        ticks=ticks,
        hazard_start=hazard_start,
        hazard_end=min(hazard_end, ticks),
        peaks={"A": min(1.0, peak_risk), "B": min(1.0, peak_risk), "C": min(1.0, peak_risk)},
        outage_start=outage_start,
        outage_end=outage_end,
        noise=SENSOR_NOISE,
        bandwidth=max(0.5, bandwidth),
        seed=seed,
        intensity=1.0,
        pfu=pfu,
        utc=utc,
        quality=quality,
        peak_index=peak,
        measured=series["measured"],
        peer_latency=max(1, int(peer_latency)),
        peer_loss=peer_loss,
        peer_availability=peer_availability,
        orbit=True,
        step_minutes=STEP_MINUTES,
        timing=REPLAY_TIMING,
    )


def run_replay(scenario: Scenario, advisor=None) -> dict:
    result = simulate(scenario, advisor=advisor)
    meta = describe(scenario.name)
    result["source"] = "noaa"
    result["stepMinutes"] = STEP_MINUTES
    result["assumption"] = NOTE
    result["catalog"] = meta["catalog"]
    result["mission"] = meta["mission"]
    result["replay"] = {
        "label": meta["label"],
        "why": meta["why"],
        "method": meta["method"],
        "satellite": meta["satellite"],
        "product": meta["product"],
        "peakUtc": meta["peakUtc"],
        "peakPfu": meta["peakPfu"],
        "files": meta["files"],
        "units": meta["units"],
        "cadenceMinutes": STEP_MINUTES,
        "sourceUrl": meta["sourceUrl"],
        "catalogUrl": meta["catalogUrl"],
        "sensorNoise": SENSOR_NOISE,
    }
    return result


def evaluate_replays(
    bandwidth: float = 3.0,
    seeds: int = 5,
    peer_latency: int = 2,
    peer_loss: float = 0.0,
) -> list[dict]:
    rows = []
    for window_id in window_ids():
        record = WINDOWS[window_id]
        results = [
            simulate(
                make_replay(
                    window_id,
                    outage_hours=record["defaultOutageHours"],
                    bandwidth=bandwidth,
                    seed=seed,
                    peer_latency=peer_latency,
                    peer_loss=peer_loss,
                )
            )
            for seed in range(1, seeds + 1)
        ]
        rows.append({"preset": window_id, "label": record["label"], "controllers": aggregate(results)})
    return rows
