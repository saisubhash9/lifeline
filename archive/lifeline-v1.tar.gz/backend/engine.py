"""Three-satellite resilience simulator.

Four controllers run on identical copies of the cluster. They share one hazard
trace, one sensor-noise draw, one hardware-telemetry draw, one peer-message
schedule, and one fault draw, so score differences come from decisions only.

Hardware faults are a labeled assumption: hit probability rises with the true
radiation risk while a payload is active. That mapping is not a measurement of
real spacecraft hardware.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

from backend.network import (
    EXPOSE_LIMIT,
    NODES,
    advisor_view,
    explain_migration,
    index_messages,
    plan_messages,
)
from backend.orbit import ORBITS, track

BASE_RISK = 0.06
SAFETY_LIMIT = 0.72
HOLD_LEVEL = 0.55
CAUTIOUS_LEVEL = 0.35
CLEAR_LEVEL = 0.28
TICKS = 180
ROLLBACK_LEVEL = 0.62
TELEMETRY_RATE = 12.0
TELEMETRY_CONFIDENCE = 0.5
AMBIENT_EXPOSURE = 0.6
SERVICE_CAPACITY = 0.95
COMPUTING = ("normal", "cautious")
ACTIVE = ("normal", "cautious", "checkpointing")
HELD = ("protected", "recovering")

ASSUMPTION = (
    "Hardware faults are a simulation assumption. Hit probability rises with the "
    "radiation-risk signal while a payload is active, and safe-hold powers the payload "
    "down, so unsaved work is lost unless it was checkpointed first. The timeline is "
    "not a historical space-weather product, and it is not a measurement of real hardware."
)


@dataclass(frozen=True)
class Timing:
    """Durations are in steps. A step is one second scripted and five minutes on replays."""

    checkpoint: int
    cautious_every: int
    normal_every: int
    recover: int
    recover_planned: int
    resume_streak: int
    ground_delay: int
    lead: int
    horizon: int
    period: int
    chunk: float
    state_size: float
    hit_scale: float
    alert_hold: int
    beacon_every: int
    memory: int


SCRIPTED_TIMING = Timing(
    checkpoint=3, cautious_every=8, normal_every=30, recover=4, recover_planned=2,
    resume_streak=5, ground_delay=12, lead=6, horizon=20, period=20, chunk=8.0,
    state_size=8.0, hit_scale=0.025, alert_hold=8, beacon_every=6, memory=0,
)
REPLAY_TIMING = Timing(
    checkpoint=1, cautious_every=4, normal_every=12, recover=2, recover_planned=1,
    resume_streak=3, ground_delay=12, lead=1, horizon=19, period=24, chunk=10.0,
    state_size=3.0, hit_scale=0.03, alert_hold=12, beacon_every=2, memory=24,
)


@dataclass
class Task:
    release: int
    due: int
    left: float


@dataclass
class Job:
    id: str
    name: str
    priority: str
    home: str
    node: str
    chunk: float = 0.0
    period: int = 0
    offset: int = 0
    tasks: list[Task] = field(default_factory=list)
    met: int = 0
    missed: int = 0
    work_done: float = 0.0
    unsaved: float = 0.0
    status: str = "running"
    migrate_to: str | None = None
    migrate_left: int = 0
    down_since: int | None = None

    @property
    def essential(self) -> bool:
        return self.priority != "best-effort"

    @property
    def critical(self) -> bool:
        return self.priority == "critical"

    @property
    def load(self) -> float:
        return self.chunk / self.period if self.period else 0.0


@dataclass
class Node:
    id: str
    mode: str = "normal"
    resume_mode: str = "normal"
    checkpoint_left: int = 0
    hold_after: bool = False
    planned: bool = False
    recover_left: int = 0
    since_checkpoint: int = 0
    uncorrectable: int = 0
    locked: bool = False


@dataclass
class Metrics:
    lost: float = 0.0
    interlocks: int = 0
    exposed: int = 0
    up_ticks: int = 0
    up_den: int = 0
    overhead: int = 0
    interruptions: list[int] = field(default_factory=list)
    migrations: int = 0
    grok_latency_ms: float | None = None


@dataclass
class World:
    nodes: dict[str, Node]
    jobs: list[Job]
    metrics: Metrics = field(default_factory=Metrics)
    reason: str = "Nominal operations."
    rolled_back: set[str] = field(default_factory=set)


@dataclass
class Scenario:
    name: str
    ticks: int
    hazard_start: int
    hazard_end: int
    peaks: dict[str, float]
    outage_start: int
    outage_end: int
    noise: float
    bandwidth: float
    seed: int
    intensity: float
    pfu: list[float] | None = None
    utc: list[str] | None = None
    quality: list[str] | None = None
    peak_index: int = 0
    measured: list[float | None] | None = None
    peer_latency: int = 2
    peer_loss: float = 0.0
    peer_availability: float = 1.0
    orbit: bool = False
    step_minutes: float = 1 / 60
    timing: Timing = SCRIPTED_TIMING


PRESETS = {
    "sustained": {
        "label": "Sustained hazard + outage",
        "hazard_start": 48,
        "hazard_end": 150,
        "peaks": {"A": 0.94, "B": 0.22, "C": 0.16},
        "noise": 0.0,
        "outage": 100,
    },
    "cluster": {
        "label": "Cluster-wide hazard",
        "hazard_start": 48,
        "hazard_end": 150,
        "peaks": {"A": 0.9, "B": 0.86, "C": 0.84},
        "noise": 0.0,
        "outage": 100,
    },
    "spike": {
        "label": "Brief spike",
        "hazard_start": 70,
        "hazard_end": 102,
        "peaks": {"A": 0.58, "B": 0.12, "C": 0.1},
        "noise": 0.0,
        "outage": 0,
    },
    "quiet": {
        "label": "Quiet conditions",
        "hazard_start": 48,
        "hazard_end": 150,
        "peaks": {"A": 0.08, "B": 0.07, "C": 0.07},
        "noise": 0.0,
        "outage": 0,
    },
    "noisy": {
        "label": "Noisy sensors",
        "hazard_start": 48,
        "hazard_end": 150,
        "peaks": {"A": 0.94, "B": 0.22, "C": 0.16},
        "noise": 0.08,
        "outage": 100,
    },
}


def make_scenario(
    preset: str = "sustained",
    intensity: float = 1.0,
    outage: int | None = None,
    bandwidth: float = 3.0,
    seed: int = 7,
    peer_latency: int = 2,
    peer_loss: float = 0.0,
    peer_availability: float = 1.0,
) -> Scenario:
    spec = PRESETS[preset]
    intensity = max(0.3, min(1.6, intensity))
    bandwidth = max(0.5, bandwidth)
    hazard_start = spec["hazard_start"]
    hazard_end = spec["hazard_end"]
    center = (hazard_start + hazard_end) // 2
    duration = spec["outage"] if outage is None else max(0, int(outage))
    if duration == 0:
        outage_start, outage_end = -1, -1
    else:
        outage_start = center - duration // 2
        outage_end = outage_start + duration
    peaks = {
        node: min(1.0, BASE_RISK + (peak - BASE_RISK) * intensity)
        for node, peak in spec["peaks"].items()
    }
    return Scenario(
        name=preset,
        ticks=TICKS,
        hazard_start=hazard_start,
        hazard_end=hazard_end,
        peaks=peaks,
        outage_start=outage_start,
        outage_end=outage_end,
        noise=spec["noise"],
        bandwidth=bandwidth,
        seed=seed,
        intensity=intensity,
        peer_latency=max(1, int(peer_latency)),
        peer_loss=peer_loss,
        peer_availability=peer_availability,
    )


_ANCHORS = ((0.0, 0.0), (1.0, 0.22), (2.0, 0.55), (3.0, 0.72), (5.0, 1.0))


def pfu_to_risk(pfu: float) -> float:
    """Map channel-sum flux onto the controller scale.

    10 pfu (S1) stays below cautious. 100 pfu (S2) meets the safe-hold threshold.
    1,000 pfu (S3) meets the safety limit. This scale is part of the simulator,
    not a NOAA data product.
    """
    if pfu <= 1:
        return 0.0
    level = math.log10(pfu)
    if level >= _ANCHORS[-1][0]:
        return 1.0
    for (left, left_risk), (right, right_risk) in zip(_ANCHORS, _ANCHORS[1:]):
        if level <= right:
            span = (level - left) / (right - left)
            return left_risk + span * (right_risk - left_risk)
    return 1.0


def risk_to_pfu(risk: float) -> float:
    """Inverse of pfu_to_risk on the anchor scale."""
    if risk <= 0:
        return 1.0
    if risk >= 1:
        return 10 ** _ANCHORS[-1][0]
    for (left, left_risk), (right, right_risk) in zip(_ANCHORS, _ANCHORS[1:]):
        if risk <= right_risk:
            span = (risk - left_risk) / (right_risk - left_risk)
            return 10 ** (left + span * (right - left))
    return 10 ** _ANCHORS[-1][0]


def link_up(t: int, scenario: Scenario) -> bool:
    return not (scenario.outage_start <= t < scenario.outage_end)


def phase_at(t: int, scenario: Scenario) -> str:
    if t < scenario.hazard_start:
        return "normal"
    if t < scenario.hazard_end:
        return "hazard"
    return "recovery"


# ---------------------------------------------------------------------------
# Shared environment: every world sees these same draws.


@dataclass
class Environment:
    true: list[dict[str, float]]
    observed: list[dict[str, float]]
    telemetry: list[dict[str, int]]
    fused: list[dict[str, float]]
    confidence: list[dict[str, float]]
    shock: list[dict[str, float]]
    exposure: list[dict[str, float]] | None
    ambient: list[dict[str, float | None]]
    positions: list[dict[str, dict]] | None
    observed_low: list[dict[str, int]]
    fused_low: list[dict[str, int]]


def _scripted_risk(t: int, node: str, scenario: Scenario) -> float:
    start, end = scenario.hazard_start, scenario.hazard_end
    peak = scenario.peaks[node]
    if t <= start or t >= end:
        return BASE_RISK
    x = (t - start) / (end - start)
    return BASE_RISK + (peak - BASE_RISK) * math.sin(math.pi * x)


def _reading_confidence(quality: str | None) -> float:
    if quality == "gap":
        return 0.0
    if quality == "degraded":
        return 0.55
    return 0.92


def _poisson(rng: random.Random, lam: float) -> int:
    if lam <= 0:
        return 0
    limit = math.exp(-lam)
    count, product = 0, rng.random()
    while product > limit:
        count += 1
        product *= rng.random()
    return count


def _streaks(rows: list[dict[str, float]]) -> list[dict[str, int]]:
    out = []
    run = {node: 0 for node in NODES}
    for row in rows:
        run = {node: run[node] + 1 if row[node] < CLEAR_LEVEL else 0 for node in NODES}
        out.append(dict(run))
    return out


def precompute(scenario: Scenario) -> Environment:
    rng = random.Random(scenario.seed)
    tele_rng = random.Random(scenario.seed + 7919)
    positions = track(scenario.ticks, scenario.step_minutes) if scenario.orbit else None
    exposure = [{node: row[node]["exposure"] for node in NODES} for row in positions] if positions else None
    true_rows, observed_rows, shocks, confidence_rows = [], [], [], []
    telemetry_rows, fused_rows, ambient_rows = [], [], []
    last_obs = {node: BASE_RISK for node in NODES}
    ewma = {node: 0.0 for node in NODES}
    for t in range(scenario.ticks):
        quality = scenario.quality[t] if scenario.quality is not None else "ok"
        gap = quality == "gap"
        if scenario.pfu is not None:
            flux = scenario.pfu[t]
            factor = exposure[t] if exposure else {node: 1.0 for node in NODES}
            true_risk = {node: pfu_to_risk(flux * factor[node]) for node in NODES}
        else:
            true_risk = {node: _scripted_risk(t, node, scenario) for node in NODES}
        observed, shock, confidence, counts, fused, ambient = {}, {}, {}, {}, {}, {}
        for node, value in true_risk.items():
            shock[node] = rng.random()
            if gap:
                observed[node] = last_obs[node]
                confidence[node] = 0.0
            else:
                noise = rng.gauss(0, scenario.noise) if scenario.noise else 0.0
                observed[node] = min(1.0, max(0.0, value + noise))
                last_obs[node] = observed[node]
                confidence[node] = _reading_confidence(quality)
            counts[node] = _poisson(tele_rng, TELEMETRY_RATE * value * value)
            ewma[node] = 0.5 * ewma[node] + 0.5 * counts[node]
            hardware = min(1.0, math.sqrt(ewma[node] / TELEMETRY_RATE))
            weight = confidence[node] + TELEMETRY_CONFIDENCE
            fused[node] = (confidence[node] * observed[node] + TELEMETRY_CONFIDENCE * hardware) / weight
            ambient[node] = None
            if exposure and exposure[t][node] >= AMBIENT_EXPOSURE:
                ambient[node] = round(pfu_to_risk(risk_to_pfu(fused[node]) / exposure[t][node]), 3)
        true_rows.append(true_risk)
        observed_rows.append(observed)
        shocks.append(shock)
        confidence_rows.append(confidence)
        telemetry_rows.append(counts)
        fused_rows.append(fused)
        ambient_rows.append(ambient)
    return Environment(
        true=true_rows,
        observed=observed_rows,
        telemetry=telemetry_rows,
        fused=fused_rows,
        confidence=confidence_rows,
        shock=shocks,
        exposure=exposure,
        ambient=ambient_rows,
        positions=positions,
        observed_low=_streaks(observed_rows),
        fused_low=_streaks(fused_rows),
    )


# ---------------------------------------------------------------------------
# Workload


# Disaster-response services. Orbits suit the job: polar for imaging, a
# broadband-style shell for the relay, low inclination for regional mapping.
# The critical relay releases half-size tasks twice as often, so its deadlines
# are tighter. Periods and work scale with the scenario timing.
SERVICES = (
    {"id": "sA", "node": "A", "name": "Imagery", "label": "Hurricane imagery downlink", "tier": "essential", "scale": 1.0},
    {"id": "sB", "node": "B", "name": "Emergency comms", "label": "Emergency comms relay", "tier": "critical", "scale": 0.5},
    {"id": "sC", "node": "C", "name": "Flood maps", "label": "Flood-mapping inference", "tier": "essential", "scale": 1.0},
)
BATCH_LABEL = "Science archive processing"
TIER_ORDER = {"critical": 0, "essential": 1, "best-effort": 2}


def initial_world(scenario: Scenario) -> World:
    timing = scenario.timing
    nodes = {
        node: Node(node, since_checkpoint=index * timing.normal_every // len(NODES))
        for index, node in enumerate(NODES)
    }
    jobs = []
    for index, spec in enumerate(SERVICES):
        period = max(2, int(timing.period * spec["scale"]))
        jobs.append(
            Job(
                spec["id"],
                spec["name"],
                spec["tier"],
                spec["node"],
                spec["node"],
                chunk=timing.chunk * spec["scale"],
                period=period,
                offset=index * (period // 3),
            )
        )
    for node in NODES:
        jobs.append(Job(f"b{node}", f"Archive-{node}", "best-effort", node, node))
    return World(nodes=nodes, jobs=jobs)


def _hosted(world: World, node_id: str) -> list[Job]:
    return [job for job in world.jobs if job.node == node_id and job.status in ("running", "paused")]


def _incoming(world: World, node_id: str) -> list[Job]:
    return [job for job in world.jobs if job.status == "migrating" and job.migrate_to == node_id]


def service_load(world: World, node_id: str) -> float:
    jobs = [job for job in _hosted(world, node_id) + _incoming(world, node_id) if job.essential]
    jobs += [job for job in world.jobs if job.status == "migrating" and job.node == node_id and job.essential]
    return sum(job.load for job in jobs)


def has_capacity(world: World, node_id: str, job: Job) -> bool:
    return service_load(world, node_id) + job.load <= SERVICE_CAPACITY


def free_slots(world: World, node_id: str) -> int:
    """Services this node could still accept. Kept for the advisor and the API."""
    spare = SERVICE_CAPACITY - service_load(world, node_id)
    unit = next((job.load for job in world.jobs if job.essential), 0.4) or 0.4
    return max(0, int(spare / unit + 1e-9))


def _lose(world: World, job: Job) -> None:
    if job.unsaved <= 0:
        return
    world.metrics.lost += job.unsaved
    if job.essential:
        if job.tasks:
            job.tasks[0].left += job.unsaved
    else:
        job.work_done -= job.unsaved
    job.unsaved = 0.0


def _commit(world: World, node_id: str) -> None:
    for job in _hosted(world, node_id):
        job.unsaved = 0.0


def _unsaved(world: World, node_id: str) -> float:
    return sum(job.unsaved for job in _hosted(world, node_id))


def _work(job: Job, budget: float, t: int) -> float:
    if not job.essential:
        job.work_done += budget
        job.unsaved += budget
        return budget
    used = 0.0
    while budget - used > 1e-9 and job.tasks:
        task = job.tasks[0]
        step = min(budget - used, task.left)
        task.left -= step
        job.unsaved += step
        used += step
        if task.left <= 1e-9:
            job.tasks.pop(0)
            job.unsaved = 0.0
            if t < task.due:
                job.met += 1
                job.work_done += job.chunk
            else:
                job.missed += 1
    return used


def _priority(job: Job) -> tuple:
    """Critical, then essential, then best-effort; earliest deadline first within a tier."""
    return (TIER_ORDER[job.priority], job.tasks[0].due if job.tasks else math.inf)


def _release_and_expire(job: Job, t: int) -> None:
    if not job.essential:
        return
    while job.tasks and job.tasks[0].due <= t:
        job.tasks.pop(0)
        job.missed += 1
        job.unsaved = 0.0
    if t >= job.offset and (t - job.offset) % job.period == 0:
        job.tasks.append(Task(t, t + job.period, job.chunk))


# ---------------------------------------------------------------------------
# Controllers. Each returns actions, planned holds, and migrations.


def _intent(actions=None, migrations=None, reason="", **extra) -> dict:
    return {"actions": actions or {}, "migrations": migrations or [], "reason": reason, "planned": set(), **extra}


def threshold_intent(world: World, env: Environment, t: int, scenario: Scenario) -> dict:
    observed = env.observed[t]
    streak = env.observed_low[t]
    actions = {}
    hot = []
    for node_id, risk in observed.items():
        mode = world.nodes[node_id].mode
        if risk >= HOLD_LEVEL and mode in ACTIVE and not world.nodes[node_id].hold_after:
            actions[node_id] = "safe-hold"
            hot.append(node_id)
        elif risk >= CAUTIOUS_LEVEL and mode == "normal":
            actions[node_id] = "cautious"
        elif risk < CLEAR_LEVEL and mode == "cautious":
            actions[node_id] = "relax"
        elif risk < CLEAR_LEVEL and mode == "protected" and streak[node_id] >= scenario.timing.resume_streak:
            actions[node_id] = "resume"
    if hot:
        names = " and ".join(f"Node {node_id}" for node_id in hot)
        reason = f"{names} checkpointed and entered safe-hold at the configured threshold."
    elif "cautious" in actions.values():
        reason = "Local risk crossed the cautious threshold. Checkpoint frequency increased."
    elif "resume" in actions.values():
        reason = "Risk stayed below the recovery threshold. Nodes are restarting."
    else:
        reason = "All nodes inside local thresholds."
    return _intent(actions, reason=reason)


def ground_intent(world: World, env: Environment, t: int, scenario: Scenario) -> dict:
    delay = scenario.timing.ground_delay
    if not link_up(t, scenario) or t < delay:
        return _intent(reason="Ground command delayed. Only the hardware interlock acts onboard.")
    delayed = env.observed[t - delay]
    streak = env.observed_low[t - delay]
    actions = {}
    for node_id, risk in delayed.items():
        node = world.nodes[node_id]
        if risk >= HOLD_LEVEL and node.mode in ACTIVE and not node.hold_after:
            actions[node_id] = "safe-hold"
        elif risk >= CAUTIOUS_LEVEL and node.mode == "normal":
            actions[node_id] = "cautious"
        elif risk < CLEAR_LEVEL and node.mode == "cautious":
            actions[node_id] = "relax"
        elif risk < CLEAR_LEVEL and node.mode == "protected" and streak[node_id] >= scenario.timing.resume_streak:
            actions[node_id] = "resume"
    reason = (
        "Ground command applied from delayed telemetry."
        if actions
        else "Ground link is up. Delayed telemetry does not request a change."
    )
    return _intent(actions, reason=reason)


class Knowledge:
    """What one node can know at step t: its own readings, its own ephemeris and
    its peers' (orbits are planned), and alerts delivered to it by step t."""

    def __init__(self, env: Environment, node: str, t: int, inbox: list[dict], scenario: Scenario):
        self.env = env
        self.node = node
        self.t = t
        self.scenario = scenario
        self.inbox = {item["sender"]: item for item in inbox}
        self.ambient: float | None = None
        self.ambient_t: int | None = None
        self.ambient_from: str | None = None
        if env.exposure is not None:
            start = max(0, t - scenario.timing.memory)
            for step in range(t, start - 1, -1):
                value = env.ambient[step][node]
                if value is not None:
                    self.ambient, self.ambient_t, self.ambient_from = value, step, node
                    break
            for item in inbox:
                if item.get("ambient") is None:
                    continue
                if self.ambient_t is None or item["obsT"] > self.ambient_t:
                    self.ambient, self.ambient_t, self.ambient_from = item["ambient"], item["obsT"], item["sender"]
        recent = [env.fused[step][node] for step in range(max(0, t - 2), t + 1)]
        earlier = [env.fused[step][node] for step in range(max(0, t - 5), max(0, t - 2) + 1)]
        self.smooth = sum(recent) / len(recent)
        gap = max(1, (len(recent) + len(earlier)) / 2)
        self.slope = (self.smooth - sum(earlier) / len(earlier)) / gap

    @property
    def reading(self) -> float:
        return self.env.fused[self.t][self.node]

    def trend(self) -> float:
        """Smoothed local reading and slope, used when there is no orbit to plan from."""
        return self.smooth

    def forecast(self, peer: str, step: int) -> float | None:
        env = self.env
        step = min(step, self.scenario.ticks - 1)
        if env.exposure is not None:
            if self.ambient is None:
                if peer == self.node:
                    return self.reading
                alert = self.inbox.get(peer)
                return alert["risk"] if alert else None
            return pfu_to_risk(risk_to_pfu(self.ambient) * env.exposure[step][peer])
        if peer == self.node:
            ahead = min(step - self.t, self.scenario.timing.lead)
            return min(1.0, max(self.reading, self.smooth + max(0.0, self.slope) * ahead) if ahead else self.reading)
        alert = self.inbox.get(peer)
        if alert is None:
            return None
        ahead = min(step - alert["obsT"], self.scenario.timing.lead)
        return min(1.0, alert["risk"] + max(0.0, alert.get("trend") or 0.0) * max(0, ahead))

    def peak(self, peer: str, first: int, last: int) -> float:
        values = [self.forecast(peer, self.t + k) for k in range(first, last + 1)]
        if any(value is None for value in values):
            return 1.0
        return max(values) if values else 0.0

    def storm(self) -> bool:
        if self.env.exposure is not None:
            return self.ambient is not None and self.ambient >= 0.45
        return self.smooth >= CAUTIOUS_LEVEL

    def all_clear(self) -> bool:
        if self.env.exposure is not None:
            return self.ambient is not None and self.ambient < CLEAR_LEVEL
        return all(item["risk"] < CLEAR_LEVEL for item in self.inbox.values()) and self.reading < CLEAR_LEVEL


def _offload_target(world: World, know: Knowledge, job: Job, t: int, rejected: list[dict]) -> str | None:
    horizon = know.scenario.timing.horizon
    options = []
    for peer in NODES:
        if peer == know.node:
            continue
        alert = know.inbox.get(peer)
        free = 1 if has_capacity(world, peer, job) and world.nodes[peer].mode in ACTIVE else 0
        ok, why = explain_migration(free, alert, t, True)
        if ok and know.peak(peer, 0, horizon) >= CAUTIOUS_LEVEL:
            ok, why = False, "target is forecast to be exposed within the planning horizon"
        if not ok:
            rejected.append({"action": "migrate", "node": know.node, "target": peer, "reason": why})
            continue
        options.append((know.peak(peer, 0, horizon), peer))
    options.sort()
    return options[0][1] if options else None


def cooperative_intent(
    world: World,
    env: Environment,
    t: int,
    inboxes: dict[str, list[dict]],
    share: bool,
    scenario: Scenario,
) -> dict:
    """Each node acts on its fused local reading, its ephemeris, and, when sharing
    is on, alerts delivered to it by this step."""
    timing = scenario.timing
    transfer = max(1, math.ceil(timing.state_size / scenario.bandwidth))
    actions: dict[str, str] = {}
    planned: set[str] = set()
    migrations: list[tuple[str, str]] = []
    proposed: list[dict] = []
    rejected: list[dict] = []
    reasons: list[str] = []
    knowledge: dict[str, Knowledge] = {}
    for node_id in NODES:
        node = world.nodes[node_id]
        know = Knowledge(env, node_id, t, inboxes.get(node_id, []) if share else [], scenario)
        knowledge[node_id] = know
        reading = know.reading
        ahead = max(reading, know.peak(node_id, 1, timing.lead))
        oriented = env.exposure is not None

        if node.mode == "protected":
            window = timing.recover_planned + timing.checkpoint + 1
            settled = oriented or env.fused_low[t][node_id] >= timing.resume_streak
            if not node.locked and reading < CAUTIOUS_LEVEL and settled and know.peak(node_id, 0, window) < 0.45:
                actions[node_id] = "resume"
                proposed.append({"action": "resume", "node": node_id, "target": None, "job": None})
                reasons.append(f"{node_id} resumed. Its reading is {reading:.2f} and the forecast stays low.")
            continue
        if node.mode == "recovering":
            continue

        handing_off = any(job.status == "migrating" and job.node == node_id for job in world.jobs)
        if handing_off and reading < HOLD_LEVEL:
            continue
        if share and node.mode in ACTIVE:
            moved = False
            hosted = [job for job in _hosted(world, node_id) if job.essential and job.status == "running"]
            for job in sorted(hosted, key=lambda item: TIER_ORDER[item.priority]):
                if job.node == job.home:
                    exposed_soon = know.storm() and know.peak(node_id, 1, timing.horizon) >= HOLD_LEVEL
                    if not oriented:
                        exposed_soon = know.smooth >= CAUTIOUS_LEVEL and (know.slope > 0.003 or know.smooth >= 0.45)
                    if not exposed_soon:
                        continue
                    if reading >= HOLD_LEVEL or (oriented and know.peak(node_id, 1, transfer) >= HOLD_LEVEL):
                        continue
                    target = _offload_target(world, know, job, t, rejected)
                    if target is None:
                        continue
                    verb = "move"
                else:
                    home = job.home
                    alert = know.inbox.get(home)
                    home_ok = (
                        know.all_clear()
                        and alert is not None
                        and alert["expires"] > t
                        and world.nodes[home].mode in ACTIVE
                        and has_capacity(world, home, job)
                        and know.peak(home, 0, timing.horizon) < CAUTIOUS_LEVEL
                    )
                    if not home_ok:
                        continue
                    target = home
                    verb = "return"
                if node.mode == "checkpointing":
                    if node.hold_after:
                        continue
                    reasons.append(f"{node_id} finishes its checkpoint before {job.name} moves to {target}.")
                elif job.unsaved > 1e-6:
                    actions[node_id] = "checkpoint"
                    proposed.append({"action": "checkpoint", "node": node_id, "target": target, "job": job.name})
                    reasons.append(f"Checkpoint {job.name} on {node_id} before it moves to {target}.")
                else:
                    migrations.append((job.id, target))
                    proposed.append({"action": "migrate", "node": node_id, "target": target, "job": job.name})
                    if verb == "move":
                        reasons.append(f"Move {job.name} from {node_id} to {target}, which is shielded for the next orbit.")
                    else:
                        reasons.append(f"All clear. {job.name} returns from {node_id} to {target}.")
                moved = True
                break
            if moved:
                continue

        if ahead >= HOLD_LEVEL and node.mode in ACTIVE and not node.hold_after:
            actions[node_id] = "safe-hold"
            if reading < HOLD_LEVEL:
                planned.add(node_id)
            proposed.append({"action": "safe-hold", "node": node_id, "target": None, "job": None})
            if reading < HOLD_LEVEL:
                reasons.append(f"{node_id} checkpoints and holds before forecast exposure of {ahead:.2f}.")
            else:
                reasons.append(f"{node_id} entered safe-hold on its local reading {reading:.2f}.")
        elif node.mode == "normal" and (reading >= CAUTIOUS_LEVEL or (know.storm() and know.peak(node_id, 1, timing.horizon) >= CAUTIOUS_LEVEL)):
            actions[node_id] = "cautious"
            proposed.append({"action": "cautious", "node": node_id, "target": None, "job": None})
            reasons.append(f"{node_id} raised checkpoint frequency ahead of rising risk.")
        elif node.mode == "cautious" and reading < CLEAR_LEVEL and not (know.storm() and know.peak(node_id, 1, timing.horizon) >= CAUTIOUS_LEVEL):
            actions[node_id] = "relax"

    evidence_node = max(NODES, key=lambda node_id: env.fused[t][node_id])
    know = knowledge[evidence_node]
    heard = ", ".join(
        f"{item['sender']} {item['risk']:.2f}" for item in (inboxes.get(evidence_node, []) if share else [])
    ) or "no fresh peer alert"
    ambient = "" if know.ambient is None else f" Ambient estimate {know.ambient:.2f} from {know.ambient_from} at step {know.ambient_t}."
    plan = "hold"
    for label, test in (
        ("migrate", bool(migrations)),
        ("checkpoint", "checkpoint" in actions.values()),
        ("safe-hold", "safe-hold" in actions.values()),
        ("cautious", "cautious" in actions.values()),
        ("resume", "resume" in actions.values()),
    ):
        if test:
            plan = label
            break
    return {
        "actions": actions,
        "planned": planned,
        "migrations": migrations,
        "reason": reasons[-1] if reasons else ("Holding." if share else "Holding without peer alerts."),
        "evidence": f"Fused reading at {evidence_node} is {env.fused[t][evidence_node]:.2f}. Delivered alerts: {heard}.{ambient}",
        "validation": "Actions use local readings, planned orbits, and alerts delivered by this step. The hardware interlock still overrides them.",
        "plan": plan,
        "target": evidence_node,
        "proposed": proposed,
        "rejected": rejected,
    }


# ---------------------------------------------------------------------------
# Applying decisions and stepping the world


def _enter_hold(world: World, node: Node, planned: bool) -> None:
    for job in _hosted(world, node.id):
        _lose(world, job)
        if job.status == "running":
            job.status = "paused"
    for job in world.jobs:
        if job.status == "migrating" and (job.node == node.id or job.migrate_to == node.id):
            job.status = "paused" if world.nodes[job.node].mode in HELD or job.node == node.id else "running"
            job.migrate_to = None
            job.migrate_left = 0
    node.mode = "protected"
    node.planned = planned
    node.hold_after = False
    node.checkpoint_left = 0


def _apply_intent(world: World, intent: dict, scenario: Scenario, controller: str) -> None:
    timing = scenario.timing
    planned = intent.get("planned", set())
    for node_id, action in intent.get("actions", {}).items():
        node = world.nodes[node_id]
        if action == "checkpoint" and node.mode in COMPUTING:
            node.resume_mode = node.mode
            node.mode = "checkpointing"
            node.checkpoint_left = timing.checkpoint
            node.hold_after = False
        elif action == "safe-hold" and node.mode in ACTIVE:
            node.planned = node_id in planned
            if node.mode == "checkpointing":
                node.hold_after = True
            elif _unsaved(world, node_id) > 1e-6:
                node.resume_mode = node.mode
                node.mode = "checkpointing"
                node.checkpoint_left = timing.checkpoint
                node.hold_after = True
            else:
                _enter_hold(world, node, node.planned)
        elif action == "cautious" and node.mode == "normal":
            node.mode = "cautious"
        elif action == "relax" and node.mode == "cautious":
            node.mode = "normal"
        elif action == "resume" and node.mode == "protected" and (not node.locked or controller == "ground"):
            node.locked = False
            node.mode = "recovering"
            node.recover_left = timing.recover_planned if node.planned else timing.recover
    transfer = max(1, math.ceil(timing.state_size / scenario.bandwidth))
    for job_id, dest in intent.get("migrations", []):
        job = next(item for item in world.jobs if item.id == job_id)
        src = world.nodes[job.node]
        if job.status != "running" or src.mode not in COMPUTING or job.unsaved > 1e-6:
            continue
        if dest == job.node or world.nodes[dest].mode not in ACTIVE or not has_capacity(world, dest, job):
            continue
        job.status = "migrating"
        job.migrate_to = dest
        job.migrate_left = transfer
        world.metrics.migrations += 1


def _interlock(world: World, true_risk: dict[str, float], controller: str) -> None:
    for node_id, node in world.nodes.items():
        if true_risk[node_id] < SAFETY_LIMIT or node.mode in HELD:
            continue
        world.metrics.interlocks += 1
        _enter_hold(world, node, planned=False)
        node.locked = controller == "ground"


def _hit(world: World, node: Node, env: Environment, t: int, scenario: Scenario) -> bool:
    risk = env.true[t][node.id]
    rollback = node.id not in world.rolled_back and risk >= ROLLBACK_LEVEL
    if rollback:
        world.rolled_back.add(node.id)
        return True
    return env.shock[t][node.id] < risk * risk * scenario.timing.hit_scale


def _execute(world: World, env: Environment, t: int, scenario: Scenario) -> None:
    timing = scenario.timing
    metrics = world.metrics
    true_risk = env.true[t]
    settled: set[str] = set()
    for job in world.jobs:
        _release_and_expire(job, t)

    for node_id, node in world.nodes.items():
        if node.mode in ACTIVE and true_risk[node_id] >= 0.45 and _hosted(world, node_id):
            metrics.exposed += 1
        if node.mode == "checkpointing":
            metrics.overhead += 1
            if _hit(world, node, env, t, scenario):
                node.uncorrectable += 1
                for job in _hosted(world, node_id):
                    _lose(world, job)
                if node.hold_after:
                    _enter_hold(world, node, node.planned)
                else:
                    node.mode = node.resume_mode
                    node.since_checkpoint = 0
                continue
            node.checkpoint_left -= 1
            if node.checkpoint_left <= 0:
                _commit(world, node_id)
                node.since_checkpoint = 0
                settled.add(node_id)
                if node.hold_after:
                    _enter_hold(world, node, node.planned)
                else:
                    node.mode = node.resume_mode
        elif node.mode == "recovering":
            metrics.overhead += 1
            node.recover_left -= 1
            if node.recover_left <= 0:
                node.mode = "normal"
                node.since_checkpoint = 0
                for job in _hosted(world, node_id):
                    if job.status == "paused":
                        job.status = "running"

    for job in world.jobs:
        if job.status != "migrating":
            continue
        metrics.overhead += 1
        job.migrate_left -= 1
        if job.migrate_left > 0:
            continue
        job.node = job.migrate_to or job.node
        job.migrate_to = None
        job.status = "running" if world.nodes[job.node].mode not in HELD else "paused"

    for node_id, node in world.nodes.items():
        if node.mode not in COMPUTING or node_id in settled:
            continue
        active = [job for job in _hosted(world, node_id) if job.status == "running"]
        if not active:
            continue
        if _hit(world, node, env, t, scenario):
            node.uncorrectable += 1
            for job in active:
                _lose(world, job)
            node.since_checkpoint = 0
            continue
        budget = 0.85 if node.mode == "cautious" else 1.0
        for job in sorted(active, key=_priority):
            budget -= _work(job, budget, t)
        node.since_checkpoint += 1
        every = timing.cautious_every if node.mode == "cautious" else timing.normal_every
        if node.since_checkpoint >= every and _unsaved(world, node_id) > 1e-6:
            node.resume_mode = node.mode
            node.mode = "checkpointing"
            node.checkpoint_left = timing.checkpoint
            node.hold_after = False

    for job in world.jobs:
        if not job.essential:
            continue
        up = job.status == "running" and world.nodes[job.node].mode in ACTIVE
        metrics.up_den += 1
        if up:
            metrics.up_ticks += 1
            if job.down_since is not None:
                metrics.interruptions.append(t - job.down_since)
                job.down_since = None
        elif job.down_since is None:
            job.down_since = t


# ---------------------------------------------------------------------------
# Reporting


def _useful(world: World) -> float:
    return sum(job.work_done for job in world.jobs)


def _mode_view(world: World, node: Node, controller: str) -> tuple[str, str]:
    if any(job.status == "migrating" and job.migrate_to == node.id for job in world.jobs):
        return "Receiving jobs", "warn"
    if any(job.status == "migrating" and job.node == node.id for job in world.jobs):
        return "Handing off", "warn"
    if node.mode == "checkpointing":
        return ("Checkpoint, then hold" if node.hold_after else "Checkpointing"), "warn"
    if node.mode == "protected":
        if node.locked:
            return "Interlocked, awaiting ground", "bad"
        return ("Planned hold" if node.planned else "Safe-hold"), "warn"
    if node.mode == "recovering":
        return "Recovering", "warn"
    if node.mode == "cautious":
        return "Cautious", "warn"
    return "Running", "ok"


def _health(node: Node, risk: float) -> str:
    if risk >= SAFETY_LIMIT or node.uncorrectable >= 3:
        return "critical"
    if risk >= CAUTIOUS_LEVEL or node.uncorrectable >= 1:
        return "degraded"
    return "healthy"


def _summary(world: World, t: int) -> dict:
    """Scores as of the end of step t. An interruption still open counts up to t."""
    metrics = world.metrics
    services = [job for job in world.jobs if job.essential]
    due = sum(job.met + job.missed for job in services)
    interruptions = metrics.interruptions + [
        t + 1 - job.down_since for job in services if job.down_since is not None
    ]
    return {
        "useful": round(_useful(world), 1),
        "batch": round(sum(job.work_done for job in world.jobs if not job.essential), 1),
        "lost": round(metrics.lost, 1),
        "missed": sum(job.missed for job in services),
        "criticalMissed": sum(job.missed for job in services if job.critical),
        "missedByService": {job.name: job.missed for job in services},
        "onTime": round(sum(job.met for job in services) / due, 3) if due else 1.0,
        "availability": metrics.up_ticks / metrics.up_den if metrics.up_den else 1.0,
        "interlocks": metrics.interlocks,
        "exposed": metrics.exposed,
        "recovery": round(sum(interruptions) / len(interruptions), 1) if interruptions else 0.0,
        "interruptions": len(interruptions),
        "downtime": sum(interruptions),
        "overhead": metrics.overhead,
        "migrations": metrics.migrations,
        "grokLatencyMs": metrics.grok_latency_ms,
    }


def _snapshot(
    worlds: dict[str, World],
    t: int,
    scenario: Scenario,
    env: Environment,
    decision: dict | None,
    trace: dict | None = None,
) -> dict:
    controllers = {}
    telemetry_total = {node: sum(row[node] for row in env.telemetry[: t + 1]) for node in NODES}
    for name, world in worlds.items():
        nodes = []
        for node_id in NODES:
            node = world.nodes[node_id]
            label, tone = _mode_view(world, node, name)
            jobs = [
                job.name
                for job in world.jobs
                if (job.node == node_id and job.status != "migrating")
                or (job.status == "migrating" and job.migrate_to == node_id)
            ]
            nodes.append(
                {
                    "id": node_id,
                    "label": label,
                    "tone": tone,
                    "risk": round(env.fused[t][node_id], 3),
                    "truth": round(env.true[t][node_id], 3),
                    "correctable": telemetry_total[node_id],
                    "uncorrectable": node.uncorrectable,
                    "health": _health(node, env.fused[t][node_id]),
                    "jobs": jobs,
                }
            )
        controllers[name] = {"nodes": nodes, "note": world.reason, "metrics": _summary(world, t)}
    frame = {
        "t": t,
        "phase": phase_at(t, scenario),
        "groundLink": link_up(t, scenario),
        "risk": {node: round(value, 3) for node, value in env.true[t].items()},
        "observed": {node: round(value, 3) for node, value in env.fused[t].items()},
        "controllers": controllers,
        "decision": decision,
        "trace": trace or {},
    }
    if env.positions is not None:
        frame["orbit"] = env.positions[t]
    if scenario.utc is not None:
        measured = scenario.measured[t] if scenario.measured is not None else scenario.pfu[t]
        frame["utc"] = scenario.utc[t]
        frame["pfu"] = None if measured is None else round(float(measured), 3)
        frame["quality"] = scenario.quality[t] if scenario.quality is not None else "ok"
        frame["gap"] = measured is None
    return frame


def _public_alert(message: dict, status: str) -> dict:
    keys = ("id", "sender", "receiver", "obsT", "sendT", "deliverT", "expires", "risk", "confidence", "kind", "exposure", "ambient", "trend")
    return {**{key: message.get(key) for key in keys}, "status": status}


def _executed(world: World, intent: dict) -> list[dict]:
    done = [
        {"action": action, "node": node_id, "target": None, "job": None}
        for node_id, action in intent.get("actions", {}).items()
    ]
    for job_id, dest in intent.get("migrations", []):
        job = next(item for item in world.jobs if item.id == job_id)
        done.append({"action": "migrate", "node": job.node, "target": dest, "job": job.name})
    return done


# ---------------------------------------------------------------------------
# Optional model advice, validated locally


_PLAN_ACTIONS = {
    "checkpoint-then-migrate": "checkpoint",
    "suspend-hot": "safe-hold",
    "cautious-hot": "cautious",
    "hold": "hold",
    "safe-hold": "safe-hold",
    "checkpoint": "checkpoint",
    "cautious": "cautious",
    "migrate": "migrate",
    "resume": "resume",
}


def merge_advice(intent: dict, advice: dict | None, world: World, inbox: list[dict], t: int) -> dict:
    """Validate one advisor proposal. A rejected proposal leaves the deterministic actions in place."""
    if not advice:
        return intent
    raw = advice.get("action") or advice.get("plan") or "hold"
    action = _PLAN_ACTIONS.get(str(raw), "hold")
    node = advice.get("node") if advice.get("node") in NODES else intent.get("target") or "A"
    target = advice.get("target")
    record = {
        "action": action,
        "node": node,
        "target": target,
        "job": advice.get("job"),
        "reason": advice.get("reason") or "",
        "evidence": advice.get("evidence") or "",
        "source": advice.get("provider") or advice.get("source") or "grok",
    }
    intent = {
        **intent,
        "actions": dict(intent.get("actions", {})),
        "planned": set(intent.get("planned", set())),
        "migrations": list(intent.get("migrations", [])),
        "proposed": list(intent.get("proposed", [])),
        "rejected": list(intent.get("rejected", [])),
    }
    intent["source"] = record["source"]
    intent["latencyMs"] = advice.get("latencyMs")
    if record["evidence"]:
        intent["evidence"] = record["evidence"]
    if record["reason"]:
        intent["reason"] = record["reason"]

    def reject(why: str) -> dict:
        intent["rejected"].append({**record, "reason": why})
        intent["advisor"] = {"proposed": record, "executed": None, "rejected": why}
        intent["validation"] = f"Advisor {action} rejected: {why}"
        return intent

    if action == "hold":
        intent["advisor"] = {"proposed": record, "executed": "hold", "rejected": None}
        intent["proposed"].append(record)
        return intent
    mode = world.nodes[node].mode
    if action == "migrate":
        alert = next((item for item in inbox if item["sender"] == target), None)
        job = next(
            (job for job in _hosted(world, node) if job.essential and job.status == "running"),
            None,
        )
        free = 1 if target in NODES and job is not None and has_capacity(world, target, job) else 0
        ok, why = explain_migration(free, alert, t, job is not None)
        if ok and job.unsaved > 1e-6:
            ok, why = False, "the job has unsaved progress; checkpoint first"
        if not ok:
            return reject(why)
        intent["migrations"].append((job.id, target))
        intent["proposed"].append({**record, "job": job.name})
        intent["advisor"] = {"proposed": record, "executed": "migrate", "rejected": None}
        intent["plan"] = "migrate"
        intent["validation"] = why + " Advisor proposal accepted."
        return intent
    if action == "resume" and mode != "protected":
        return reject("node is not in safe-hold")
    if action == "cautious" and mode != "normal":
        return reject("cautious mode only starts from normal operation")
    if action == "checkpoint" and mode not in COMPUTING:
        return reject("checkpoint is already underway or the node is held")
    if action == "safe-hold" and mode not in ACTIVE:
        return reject("node is already held")
    intent["actions"][node] = action
    if action == "safe-hold":
        intent["planned"].add(node)
    intent["proposed"].append(record)
    intent["advisor"] = {"proposed": record, "executed": action, "rejected": None}
    intent["plan"] = action
    intent["validation"] = "Advisor proposal passed local validation. The hardware interlock still applies."
    return intent


def _valid_actions(world: World, node_id: str) -> list[str]:
    """Actions merge_advice would accept for this node right now, before peer checks."""
    mode = world.nodes[node_id].mode
    valid = ["hold"]
    if mode == "normal":
        valid.append("cautious")
    if mode in COMPUTING:
        valid.append("checkpoint")
        if any(job.essential and job.status == "running" for job in _hosted(world, node_id)):
            valid.append("migrate")
    if mode in ACTIVE:
        valid.append("safe-hold")
    if mode == "protected":
        valid.append("resume")
    return valid


def _meaningful(previous: dict[str, float], current: dict[str, float], arrived: list[dict]) -> str | None:
    for node in NODES:
        before = previous.get(node, 0.0)
        for limit in (CAUTIOUS_LEVEL, HOLD_LEVEL, SAFETY_LIMIT):
            if before < limit <= current[node]:
                return node
    for message in arrived:
        if message["kind"] == "alert":
            return message["receiver"]
    return None


# ---------------------------------------------------------------------------
# Main loop


def simulate(scenario: Scenario, advisor=None) -> dict:
    env = precompute(scenario)
    timing = scenario.timing
    messages = plan_messages(
        env.fused,
        env.confidence,
        latency=scenario.peer_latency,
        loss=scenario.peer_loss,
        availability=scenario.peer_availability,
        seed=scenario.seed,
        exposure=env.exposure,
        ambient=env.ambient,
        hold=timing.alert_hold,
        beacon_every=timing.beacon_every,
    )
    grouped = index_messages(messages)
    cursors = {node: 0 for node in NODES}
    latest = {node: {} for node in NODES}
    worlds = {name: initial_world(scenario) for name in ("ground", "threshold", "adaptive", "local")}
    logs: list[dict] = []
    frames = []
    latest_decision = None
    last_trace: dict = {}
    advice_calls = 0
    previous = {node: BASE_RISK for node in NODES}

    for t in range(scenario.ticks):
        arrived: list[dict] = []
        for node in NODES:
            queued = grouped[node]
            index = cursors[node]
            while index < len(queued) and queued[index]["deliverT"] <= t:
                message = queued[index]
                arrived.append(message)
                if message["expires"] > t:
                    latest[node][message["sender"]] = message
                index += 1
            cursors[node] = index
            latest[node] = {sender: item for sender, item in latest[node].items() if item["expires"] > t}
        inboxes = {node: list(latest[node].values()) for node in NODES}

        intents = {
            "ground": ground_intent(worlds["ground"], env, t, scenario),
            "threshold": threshold_intent(worlds["threshold"], env, t, scenario),
            "adaptive": cooperative_intent(worlds["adaptive"], env, t, inboxes, True, scenario),
            "local": cooperative_intent(worlds["local"], env, t, inboxes, False, scenario),
        }
        trigger = _meaningful(previous, env.fused[t], arrived)
        if trigger and advisor and advice_calls < 3:
            jobs = [
                {"name": job.name, "node": job.node, "home": job.home, "priority": job.priority, "status": job.status}
                for job in worlds["adaptive"].jobs
            ]
            forecast = None
            if env.exposure is not None:
                forecast = [env.exposure[min(t + k, scenario.ticks - 1)][trigger] for k in range(1, timing.lead + 3)]
            utc = scenario.utc[t] if scenario.utc is not None else None
            state = advisor_view(trigger, t, env.fused, inboxes[trigger], jobs, utc, forecast)
            state["nodeModes"] = {node: worlds["adaptive"].nodes[node].mode for node in NODES}
            state["validActions"] = _valid_actions(worlds["adaptive"], trigger)
            advice = advisor(state)
            advice_calls += 1
            if advice and worlds["adaptive"].metrics.grok_latency_ms is None:
                worlds["adaptive"].metrics.grok_latency_ms = advice.get("latencyMs")
            intents["adaptive"] = merge_advice(intents["adaptive"], advice, worlds["adaptive"], inboxes[trigger], t)
        plan = intents["adaptive"]
        if plan.get("plan") != "hold":
            advice_record = plan.get("advisor") or {}
            decision = {
                "t": t,
                "source": plan.get("source", "fallback"),
                "evidence": plan.get("evidence"),
                "action": plan.get("reason"),
                "validation": plan.get("validation"),
                "latencyMs": plan.get("latencyMs"),
                "proposed": advice_record.get("proposed"),
                "executed": advice_record.get("executed") if advice_record else plan.get("plan"),
                "rejected": advice_record.get("rejected"),
            }
            if latest_decision is None or latest_decision.get("action") != decision["action"]:
                latest_decision = decision
        trace = {
            "confidence": {node: env.confidence[t][node] for node in NODES},
            "telemetry": {node: env.telemetry[t][node] for node in NODES},
            "inbox": {node: [_public_alert(item, "delivered") for item in inboxes[node]] for node in NODES},
            "deliveries": [_public_alert(item, "delivered") for item in arrived],
            "proposed": plan.get("proposed", []),
            "executed": _executed(worlds["adaptive"], plan),
            "rejected": plan.get("rejected", []),
            "advisor": plan.get("advisor"),
            "localProposed": intents["local"].get("proposed", []),
        }
        last_trace = trace
        previous = env.fused[t]

        for name, intent in intents.items():
            world = worlds[name]
            acted = bool(intent.get("actions") or intent.get("migrations"))
            if acted and intent.get("reason") and intent["reason"] != world.reason:
                world.reason = intent["reason"]
                logs.append({"t": t, "controller": name, "text": intent["reason"]})
            elif name == "ground" and not link_up(t, scenario):
                world.reason = intent["reason"]
            _apply_intent(world, intent, scenario, name)
            _interlock(world, env.true[t], name)
            _execute(world, env, t, scenario)

        frames.append(_snapshot(worlds, t, scenario, env, latest_decision, trace))

    frames[-1] = _snapshot(worlds, scenario.ticks - 1, scenario, env, latest_decision, last_trace)
    summary = {name: frames[-1]["controllers"][name]["metrics"] for name in worlds}
    moves = [
        frame["t"]
        for frame in frames
        if any(item["action"] == "migrate" for item in frame["trace"].get("executed") or [])
    ]
    if moves:
        highlight = moves[0]
    else:
        highlight = scenario.peak_index if scenario.pfu is not None else scenario.hazard_start
    if scenario.pfu is not None:
        phases = {
            "normal": 0,
            "hazard": highlight,
            "recovery": min(scenario.hazard_end, scenario.ticks - 1),
        }
    else:
        phases = {"normal": 8, "hazard": highlight, "recovery": scenario.hazard_end + 4}
    return {
        "assumption": ASSUMPTION,
        "source": "noaa" if scenario.pfu is not None else "scripted",
        "preset": scenario.name,
        "ticks": scenario.ticks,
        "highlight": highlight,
        "phases": phases,
        "frames": frames,
        "log": logs,
        "summary": summary,
        "peerLatency": scenario.peer_latency,
        "advisorCalls": advice_calls,
        "services": [
            {key: spec[key] for key in ("id", "node", "name", "label", "tier")} for spec in SERVICES
        ] + [{"id": "batch", "node": None, "name": "Archive", "label": BATCH_LABEL, "tier": "best-effort"}],
        "orbits": {node: {"label": orbit.label, "inclination": orbit.inclination} for node, orbit in ORBITS.items()}
        if scenario.orbit
        else None,
    }


# ---------------------------------------------------------------------------
# Batch evaluation

CONTROLLERS = ("ground", "threshold", "adaptive", "local")
SCORE_KEYS = (
    "useful", "batch", "lost", "missed", "criticalMissed", "onTime", "availability", "interlocks",
    "exposed", "recovery", "downtime", "overhead", "migrations",
)


def aggregate(results: list[dict]) -> dict:
    """Mean of each score across seeds, plus the spread of useful work."""
    summary = {}
    for name in CONTROLLERS:
        samples = [result["summary"][name] for result in results]
        row = {key: _mean(samples, key) for key in SCORE_KEYS}
        row["usefulSpread"] = _stdev(samples, "useful")
        row["lostSpread"] = _stdev(samples, "lost")
        summary[name] = row
    return summary


HEADLINE_KEYS = ("useful", "lost", "missed", "criticalMissed", "downtime", "interlocks")


def headline(rows: list[dict], skip: tuple[str, ...] = ()) -> dict:
    """Totals across scenarios, and the adaptive change against each baseline."""
    totals = {name: {key: 0.0 for key in HEADLINE_KEYS} for name in CONTROLLERS}
    for row in rows:
        if row["preset"] in skip:
            continue
        for name in CONTROLLERS:
            for key in totals[name]:
                totals[name][key] += row["controllers"][name][key]
    change = {}
    for base in ("ground", "threshold", "local"):
        change[base] = {
            key: None if totals[base][key] == 0 else round(100 * (totals["adaptive"][key] - totals[base][key]) / totals[base][key], 1)
            for key in totals[base]
        }
    return {"totals": {name: {k: round(v, 1) for k, v in row.items()} for name, row in totals.items()}, "change": change}


def evaluate(
    intensity: float = 1.0,
    outage: int | None = None,
    bandwidth: float = 3.0,
    seeds: int = 8,
    peer_latency: int = 2,
    peer_loss: float = 0.0,
) -> list[dict]:
    rows = []
    for preset, spec in PRESETS.items():
        duration = spec["outage"] if outage is None else outage
        results = [
            simulate(
                make_scenario(
                    preset,
                    intensity=intensity,
                    outage=duration,
                    bandwidth=bandwidth,
                    seed=seed,
                    peer_latency=peer_latency,
                    peer_loss=peer_loss,
                )
            )
            for seed in range(1, seeds + 1)
        ]
        rows.append({"preset": preset, "label": spec["label"], "controllers": aggregate(results)})
    return rows


def _mean(samples: list[dict], key: str) -> float:
    values = [sample[key] for sample in samples if sample[key] is not None]
    if not values:
        return 0.0
    return round(sum(values) / len(values), 3)


def _stdev(samples: list[dict], key: str) -> float:
    values = [sample[key] for sample in samples if sample[key] is not None]
    if len(values) < 2:
        return 0.0
    avg = sum(values) / len(values)
    var = sum((value - avg) ** 2 for value in values) / (len(values) - 1)
    return round(math.sqrt(var), 2)
