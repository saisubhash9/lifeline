"""Dashboard API for the orbital resilience experiment."""

from __future__ import annotations

import os
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from backend.engine import PRESETS, evaluate, headline, make_scenario, simulate
from backend.grok_client import advise_state, debrief
from backend.replay import (
    SOURCE_URL,
    STEP_MINUTES,
    UNITS,
    WINDOWS,
    describe,
    evaluate_replays,
    make_replay,
    run_replay,
    window_ids,
)

ROOT = Path(__file__).resolve().parent.parent
WEB = ROOT / "web"


def load_env() -> None:
    path = ROOT / ".env"
    if not path.exists():
        return
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


load_env()

app = FastAPI(title="Orbital resilience")
app.mount("/assets", StaticFiles(directory=WEB), name="assets")


class RunRequest(BaseModel):
    source: str = "noaa"
    preset: str = "oct2024"
    intensity: float = Field(1.0, ge=0.3, le=1.6)
    outage: int = Field(100, ge=0, le=160)
    outage_hours: int | None = Field(None, ge=0, le=96)
    bandwidth: float = Field(3.0, ge=0.5, le=12)
    peer_latency: int = Field(2, ge=1, le=12)
    peer_loss: float = Field(0.0, ge=0.0, le=0.5)
    seed: int = 7
    use_grok: bool = False


@app.get("/")
def index() -> FileResponse:
    return FileResponse(WEB / "index.html")


@app.get("/api/events")
def events() -> dict:
    names = [name for name in window_ids() if name != "quiet2024"]
    return {
        "events": [describe(name) for name in names],
        "control": describe("quiet2024") if "quiet2024" in WINDOWS else None,
        "sourceUrl": SOURCE_URL,
        "units": UNITS,
        "cadenceMinutes": STEP_MINUTES,
    }


def build_scenario(body: RunRequest):
    if body.source != "scripted":
        window_id = body.preset if body.preset in WINDOWS else "oct2024"
        return make_replay(
            window_id,
            outage_hours=body.outage_hours,
            bandwidth=body.bandwidth,
            seed=body.seed,
            peer_latency=body.peer_latency,
            peer_loss=body.peer_loss,
        )
    return make_scenario(
        preset=body.preset if body.preset in PRESETS else "sustained",
        intensity=body.intensity,
        outage=body.outage,
        bandwidth=body.bandwidth,
        seed=body.seed,
        peer_latency=body.peer_latency,
        peer_loss=body.peer_loss,
    )


def debrief_facts(result: dict, scenario) -> dict:
    minutes = STEP_MINUTES if result["source"] == "noaa" else None
    frames = result["frames"]

    def when(t: int) -> str:
        return frames[t].get("utc") or f"t={t}s"

    moves = []
    holds = []
    for entry in result["log"]:
        if entry["controller"] != "adaptive":
            continue
        if "Move " in entry["text"] or "returns" in entry["text"]:
            moves.append(f"{when(entry['t'])}: {entry['text']}")
        elif "holds before" in entry["text"] or "entered safe-hold" in entry["text"]:
            holds.append(entry["t"])
    events = {
        "serviceMoves": moves[:10],
        "plannedHoldsBeforeExposure": len(holds),
        "firstHold": when(holds[0]) if holds else None,
        "lastHold": when(holds[-1]) if holds else None,
    }
    services = {item["name"]: item for item in result.get("services", [])}
    names = {
        "ground": "Ground-dependent",
        "threshold": "Isolated fixed-threshold",
        "adaptive": "Cooperative adaptive",
        "local": "Cooperative without peer sharing",
    }
    scores = {}
    for name, metrics in result["summary"].items():
        scores[names[name]] = {
            "missedServiceDeadlines": metrics["missed"],
            "missedEmergencyCommsDeadlines": metrics["criticalMissed"],
            "missedDeadlinesByService": {
                services.get(name, {}).get("label", name): count for name, count in metrics["missedByService"].items()
            },
            "lostComputationUnits": metrics["lost"],
            "essentialServiceAvailabilityPct": round(metrics["availability"] * 100, 1),
            "serviceDowntime": f"{metrics['downtime'] * minutes} minutes" if minutes else f"{metrics['downtime']} s",
            "meanTimeToRestore": f"{round(metrics['recovery'] * minutes)} minutes" if minutes else f"{metrics['recovery']} s",
            "hardwareInterlocks": metrics["interlocks"],
            "serviceMigrations": metrics["migrations"],
        }
    facts = {
        "source": "NOAA GOES-18 replay" if result["source"] == "noaa" else "scripted scenario",
        "event": (result.get("replay") or {}).get("label") or scenario.name,
        "whyThisEvent": (result.get("replay") or {}).get("why"),
        "peakFluxPfu": (result.get("replay") or {}).get("peakPfu"),
        "peakUtc": (result.get("replay") or {}).get("peakUtc"),
        "stepLength": f"{minutes} minutes" if minutes else "1 second",
        "simulatedGroundLinkOutage": None if scenario.outage_start < 0 else f"{when(max(0, scenario.outage_start))} to {when(min(scenario.ticks - 1, scenario.outage_end))}",
        "satellites": result.get("orbits") or "scripted, no orbits",
        "services": [
            {"name": item["label"], "home": item["node"], "priority": item["tier"]}
            for item in result.get("services", [])
        ],
        "realWorldContext": {
            key: (result.get("mission") or {}).get(key) for key in ("headline", "context", "timeline")
        }
        if result.get("mission")
        else None,
        "whatIf": (result.get("mission") or {}).get("whatIf"),
        "events": events,
        "scores": scores,
        "note": "All scores are simulator outputs. Faults, workloads, and orbits are simulated.",
    }
    return facts


@app.post("/api/debrief")
def run_debrief(body: RunRequest) -> dict:
    if not os.environ.get("XAI_API_KEY") and not os.environ.get("OPENAI_API_KEY"):
        return {"text": None, "warning": "No model key is set."}
    scenario = build_scenario(body)
    result = run_replay(scenario) if body.source != "scripted" else simulate(scenario)
    facts = debrief_facts(result, scenario)
    report = debrief(facts)
    if report is None:
        return {"text": None, "warning": "The model did not return a debrief.", "facts": facts}
    return {**report, "facts": facts}


@app.post("/api/run")
def run(body: RunRequest) -> dict:
    use_replay = body.source != "scripted"
    scenario = build_scenario(body)
    warning = None
    advisor = None
    if body.use_grok:
        if not os.environ.get("XAI_API_KEY") and not os.environ.get("OPENAI_API_KEY"):
            warning = "No model key is set, so the adaptive column used the deterministic fallback."
        else:
            advisor = advise_state
            warning = "Ask Grok sends a remote API call that emulates onboard advice. It is not an onboard flight computer."
    if use_replay:
        result = run_replay(scenario, advisor=advisor)
        result["stepMinutes"] = STEP_MINUTES
    else:
        result = simulate(scenario, advisor=advisor)
    if advisor is None and body.use_grok and warning and "No model" not in warning and result.get("advisorCalls", 0) == 0:
        warning = "The model was not called. Deterministic protection was applied."
    result["warning"] = warning
    result["grok"] = bool(advisor) and result.get("advisorCalls", 0) > 0
    return result


@app.post("/api/evaluate")
def evaluate_runs(body: RunRequest) -> dict:
    if body.source != "scripted":
        rows = evaluate_replays(
            bandwidth=body.bandwidth,
            seeds=5,
            peer_latency=body.peer_latency,
            peer_loss=body.peer_loss,
        )
        return {
            "rows": rows,
            "headline": headline(rows, skip=("quiet2024",)),
            "seeds": 5,
            "source": "noaa",
            "stepMinutes": STEP_MINUTES,
        }
    rows = evaluate(
        intensity=body.intensity,
        bandwidth=body.bandwidth,
        seeds=5,
        peer_latency=body.peer_latency,
        peer_loss=body.peer_loss,
    )
    return {
        "rows": rows,
        "headline": headline(rows, skip=("quiet",)),
        "seeds": 5,
        "source": "scripted",
        "stepMinutes": 1,
    }
