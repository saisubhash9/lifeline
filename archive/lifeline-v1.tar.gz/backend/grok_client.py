"""Optional Grok decision. Metrics always come from the simulator, not from the model."""

from __future__ import annotations

import json
import os
import ssl
import time
import urllib.error
import urllib.request

try:
    import certifi

    _SSL = ssl.create_default_context(cafile=certifi.where())
except ImportError:
    _SSL = ssl.create_default_context()


def _provider() -> dict | None:
    xai_key = os.environ.get("XAI_API_KEY", "")
    if xai_key:
        return {
            "name": "grok",
            "key": xai_key,
            "model": os.environ.get("XAI_MODEL", "grok-4"),
            "url": "https://api.x.ai/v1/chat/completions",
        }
    openai_key = os.environ.get("OPENAI_API_KEY", "")
    if openai_key:
        return {
            "name": "openai",
            "key": openai_key,
            "model": os.environ.get("OPENAI_MODEL", "gpt-4o"),
            "url": "https://api.openai.com/v1/chat/completions",
        }
    return None


def _complete(provider: dict, messages: list, tools: list) -> dict:
    payload = {"model": provider["model"], "temperature": 0, "messages": messages}
    if tools:
        payload["tools"] = tools
    body = json.dumps(payload).encode()
    request = urllib.request.Request(
        provider["url"],
        data=body,
        headers={"Authorization": f"Bearer {provider['key']}", "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=45, context=_SSL) as response:
        payload = json.loads(response.read().decode())
    return payload["choices"][0]["message"]


def _parse(content: str) -> dict:
    text = content.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
        text = text.strip()
    data = json.loads(text)
    aliases = {
        "checkpoint-then-migrate": "checkpoint",
        "suspend-hot": "safe-hold",
        "cautious-hot": "cautious",
    }
    action = str(data.get("action") or aliases.get(str(data.get("plan", "hold")), data.get("plan", "hold")))
    if action not in ("hold", "cautious", "checkpoint", "safe-hold", "migrate", "resume"):
        action = "hold"
    target = data.get("target")
    if target not in ("A", "B", "C"):
        target = None
    return {
        "action": action,
        "plan": action,
        "target": target,
        "job": data.get("job"),
        "evidence": str(data.get("evidence", "")),
        "reason": str(data.get("reason", "")),
    }


def advise_state(state: dict) -> dict | None:
    """Ask the configured model about one visible state. Returns None when no key or no parseable plan."""
    provider = _provider()
    if provider is None or state.get("usesFuture"):
        return None
    messages = [
        {
            "role": "system",
            "content": (
                "You emulate an onboard advisor for one satellite. This call is a remote API "
                "standing in for that onboard model. Use only the JSON state. Do not assume future flux. "
                "plannedExposureAhead is this satellite's exposure factor from its planned orbit for the "
                "next steps (1 means inside the polar cap). A peer alert's ambient field is that peer's "
                "estimate of the unshielded flux on the 0-1 risk scale. nodeModes gives each "
                "satellite's current mode; choose only from validActions. Jobs carry a priority: "
                "critical (emergency comms relay) outranks essential (hurricane imagery, flood maps), "
                "which outranks best-effort archive work. "
                "Reply with JSON: "
                '{"action":"hold|cautious|checkpoint|safe-hold|migrate|resume",'
                '"target":"A|B|C|null","job":"name or null","reason":"...","evidence":"..."}'
            ),
        },
        {"role": "user", "content": json.dumps(state)},
    ]
    tools = [
        {
            "type": "function",
            "function": {
                "name": "get_node_state",
                "description": "Return the deciding node's visible telemetry, delivered alerts, and jobs.",
                "parameters": {"type": "object", "properties": {}},
            },
        }
    ]
    started = time.perf_counter()
    try:
        for _ in range(3):
            message = _complete(provider, messages, tools)
            calls = message.get("tool_calls") or []
            if not calls:
                parsed = _parse(message.get("content") or "")
                parsed["latencyMs"] = round((time.perf_counter() - started) * 1000, 1)
                parsed["provider"] = provider["name"]
                parsed["node"] = state.get("node")
                return parsed
            messages.append(message)
            for call in calls:
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": call.get("id"),
                        "content": json.dumps(state),
                    }
                )
    except (urllib.error.URLError, TimeoutError, RuntimeError, KeyError, json.JSONDecodeError):
        return None
    return None


def debrief(facts: dict) -> dict | None:
    """Ask the model for a short post-run report. Every number must come from `facts`."""
    provider = _provider()
    if provider is None:
        return None
    messages = [
        {
            "role": "system",
            "content": (
                "You write a short debrief for emergency-response coordinators about how a small "
                "constellation of disaster-response satellites (hurricane imagery, emergency comms relay, "
                "flood mapping) would have fared through a real solar radiation storm. Use only the JSON "
                "facts. Quote numbers exactly as given and invent none. This is a what-if simulation: "
                "real events set the dates and radiation, but the satellites and outcomes are simulated; "
                "never claim real satellites failed or succeeded. Speak in terms of what responders would "
                "have lost or kept (emergency comms first). Plain text, no markdown headings, at most 180 "
                "words, four short paragraphs: the real-world situation, what the cooperative satellites "
                "did and when, how the four strategies compared for responders, and one limitation."
            ),
        },
        {"role": "user", "content": json.dumps(facts)},
    ]
    started = time.perf_counter()
    try:
        message = _complete(provider, messages, [])
    except (urllib.error.URLError, TimeoutError, KeyError, json.JSONDecodeError):
        return None
    text = (message.get("content") or "").strip()
    if not text:
        return None
    return {
        "text": text,
        "provider": provider["name"],
        "model": provider["model"],
        "latencyMs": round((time.perf_counter() - started) * 1000, 1),
    }
