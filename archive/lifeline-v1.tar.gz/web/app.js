const NAMES = {
  ground: "Ground-dependent",
  threshold: "Fixed-threshold",
  adaptive: "Cooperative adaptive",
  local: "Adaptive, no sharing",
};
const ORDER = ["ground", "threshold", "adaptive"];

const state = {
  run: null,
  t: 0,
  playing: false,
  speed: 8,
  timer: null,
  token: 0,
  selected: "A",
};

const $ = (id) => document.getElementById(id);

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  }[ch]));
}

function clock(t) {
  const mins = Math.floor(t / 60);
  const secs = String(t % 60).padStart(2, "0");
  return `${mins}:${secs}`;
}

const NOAA_PRESETS = [
  ["mar2024", "Mar 22–25, 2024", 24],
  ["may2024", "May 9–13, 2024 · Gannon storm", 24],
  ["jun2024", "Jun 7–10, 2024", 24],
  ["oct2024", "Oct 8–12, 2024 · Hurricane Milton", 24],
  ["jan2026", "Jan 17–22, 2026 · S4 stress test", 24],
  ["quiet2024", "Jul 18–22, 2024 · quiet control", 0],
];
const SCRIPTED_PRESETS = [
  ["sustained", "Sustained hazard + outage", 100],
  ["cluster", "Cluster-wide hazard", 100],
  ["spike", "Brief spike", 0],
  ["quiet", "Quiet conditions", 0],
  ["noisy", "Noisy sensors", 100],
];

function isNoaa() {
  return $("source").value !== "scripted";
}

function payload() {
  return {
    source: isNoaa() ? "noaa" : "scripted",
    preset: $("preset").value,
    intensity: Number($("intensity").value),
    outage: isNoaa() ? 100 : Number($("outage").value),
    outage_hours: isNoaa() ? Number($("outage").value) : null,
    bandwidth: Number($("bandwidth").value),
    peer_latency: Number($("peer").value),
    peer_loss: 0,
    seed: 7,
    use_grok: $("grok").checked,
  };
}

function syncOutputs() {
  $("intensity-out").textContent = Number($("intensity").value).toFixed(1);
  $("outage-out").textContent = isNoaa() ? `${$("outage").value}h` : `${$("outage").value}s`;
  $("bandwidth-out").textContent = $("bandwidth").value;
  $("peer-out").textContent = `${$("peer").value} steps`;
}

async function loadRun() {
  const token = ++state.token;
  stop();
  $("caption").textContent = $("grok").checked
    ? "Asking Grok, then scoring the run in the simulator…"
    : isNoaa()
      ? "GOES-18 channel sum · simulated faults · simulator scores"
      : "Scripted hazard · simulated faults · simulator scores";
  const response = await fetch("/api/run", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload()),
  });
  if (!response.ok || token !== state.token) return;
  state.run = await response.json();
  state.t = state.run.highlight ?? state.run.phases.hazard ?? 0;
  state.playing = false;
  $("caption").textContent = state.run.warning
    ? state.run.warning
    : isNoaa()
      ? "GOES-18 channel sum · simulated faults · simulator scores"
      : "Scripted hazard · simulated faults · simulator scores";
  $("assumption").textContent = state.run.assumption;
  $("dash-note").textContent = state.run.source === "noaa"
    ? "Each step is five minutes. The gold trace is the shared GOES-18 measurement. Dashed traces are each satellite's simulated local reading: the same flux, shielded by the geomagnetic field except over the polar caps. 100 pfu meets safe-hold and 1,000 pfu meets the safety limit on the simulator scale."
    : "The radiation curve is scripted. Faults and scores are simulated. Model advice, when requested, is labeled separately and still has to pass the safety rule.";
  $("debrief-text").innerHTML = "";
  renderMission();
  renderCatalog();
  renderSource();
  render();
  loadEval(token);
}

async function loadEval(token) {
  $("eval-note").textContent = isNoaa()
    ? "Five seeds on each NOAA window, at that window’s own default outage. The proton series, orbits, and peer-link settings stay fixed. Seeds change sensor noise, hardware telemetry, and faults. No share is the cooperative policy with peer alerts withheld."
    : "Five seeds per preset, at the selected intensity and bandwidth. Outage length stays on each preset’s own default. Figures are simulator averages, not spacecraft measurements.";
  $("eval-headline").innerHTML = "";
  $("eval-body").textContent = isNoaa()
    ? "Running five seeds on each NOAA window…"
    : "Running five seeds on each preset…";
  const response = await fetch("/api/evaluate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload()),
  });
  if (!response.ok || token !== state.token) return;
  const data = await response.json();
  const names = ["ground", "threshold", "adaptive"].concat(data.rows.some((row) => row.controllers.local) ? ["local"] : []);
  const labels = { ground: "Ground", threshold: "Fixed", adaptive: "Cooperative", local: "No share" };
  const minutes = data.stepMinutes || 1;
  const head = names.map((name) => `<th>${labels[name]}</th>`).join("");
  const body = data.rows.map((row) => {
    const missed = names.map((name) => row.controllers[name].missed);
    const lost = names.map((name) => row.controllers[name].lost);
    const cells = names.map((name, index) => {
      const item = row.controllers[name];
      const best = (values, value) => new Set(values).size > 1 && value === Math.min(...values);
      const downtime = minutes > 1 ? `${((item.downtime * minutes) / 60).toFixed(1)} h down` : `${item.downtime.toFixed(0)} s down`;
      return `<td><span class="${best(missed, item.missed) ? "best" : ""}">${item.missed.toFixed(1)} missed</span> <span class="muted">(${item.criticalMissed.toFixed(1)} comms)</span><br><span class="muted"><span class="${best(lost, item.lost) ? "best" : ""}">${item.lost.toFixed(1)} lost</span> · ${downtime}${item.interlocks ? ` · ${item.interlocks.toFixed(1)} interlocks` : ""}</span></td>`;
    }).join("");
    return `<tr><td>${esc(row.label)}</td>${cells}</tr>`;
  }).join("");
  $("eval-body").innerHTML = `<table><thead><tr><th>Scenario · per run</th>${head}</tr></thead><tbody>${body}</tbody></table>`;
  renderHeadline(data);
}

function renderHeadline(data) {
  const box = $("eval-headline");
  if (!data.headline) {
    box.innerHTML = "";
    return;
  }
  const change = data.headline.change;
  const totals = data.headline.totals;
  const pct = (value) => (value == null ? "—" : `${value > 0 ? "+" : ""}${value.toFixed(0)}%`);
  const tile = (label, key, base) => {
    const value = change[base][key];
    const good = value != null && value < 0;
    return `<div class="tile"><p class="tile-label">${esc(label)}</p><p class="tile-value ${good ? "good" : ""}">${pct(value)}</p><p class="tile-sub">${totals.adaptive[key].toFixed(1)} vs ${totals[base][key].toFixed(1)}</p></div>`;
  };
  const scope = data.source === "noaa" ? "all five storm windows" : "the four hazard presets";
  box.innerHTML = `<p class="muted">Cooperative adaptive against the isolated fixed-threshold baseline, summed over ${scope} (quiet control excluded).</p>
    <div class="tiles">
      ${tile("Emergency comms deadlines missed", "criticalMissed", "threshold")}
      ${tile("All service deadlines missed", "missed", "threshold")}
      ${tile("Lost computation", "lost", "threshold")}
      ${tile("Service downtime", "downtime", "threshold")}
      ${tile("Hardware interlocks", "interlocks", "threshold")}
    </div>
    <p class="muted">Against ground-dependent: missed deadlines ${pct(change.ground.missed)}, lost computation ${pct(change.ground.lost)}, downtime ${pct(change.ground.downtime)}. Sharing alone, against the same policy with no peer alerts: missed deadlines ${pct(change.local.missed)}, lost computation ${pct(change.local.lost)}, downtime ${pct(change.local.downtime)}.</p>`;
}

async function loadDebrief() {
  const button = $("debrief-button");
  const box = $("debrief-text");
  const token = state.token;
  button.disabled = true;
  box.innerHTML = `<p class="muted">Asking Grok…</p>`;
  try {
    const response = await fetch("/api/debrief", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload()),
    });
    const data = await response.json();
    if (token !== state.token) return;
    if (!data.text) {
      box.innerHTML = `<p class="muted">${esc(data.warning || "No debrief returned.")}</p>`;
      return;
    }
    const paragraphs = data.text.split(/\n\s*\n/).map((part) => `<p>${esc(part.trim())}</p>`).join("");
    box.innerHTML = `${paragraphs}<p class="muted">${esc(data.provider === "grok" ? "Grok" : "OpenAI backup")} · ${esc(data.model)} · ${(data.latencyMs / 1000).toFixed(1)} s. Model-written summary of simulator outputs.</p>`;
  } catch (error) {
    box.innerHTML = `<p class="muted">The debrief request failed.</p>`;
  } finally {
    button.disabled = false;
  }
}

$("debrief-button").addEventListener("click", loadDebrief);

function frame() {
  if (!state.run) return null;
  return state.run.frames[Math.min(state.t, state.run.frames.length - 1)];
}

function render() {
  const current = frame();
  if (!current) return;
  renderChrome(current);
  renderChart();
  renderStorm(current);
  renderGraph(current);
  renderNodeReadout(current);
  $("stage").innerHTML = `${renderBoard(current)}${renderLower(current)}`;
  $("play").textContent = state.playing ? "Pause" : "Play";
  $("play").classList.toggle("on", state.playing);
  $("clock").textContent = current.utc
    ? `${current.utc.replace("T", " ").replace(".000Z", " UTC").replace("Z", " UTC")}${current.pfu == null ? "" : ` · ${formatPfu(current.pfu)} pfu`}`
    : `${clock(current.t)} / ${clock(state.run.ticks - 1)}`;
  renderKey();
  const chart = $("chart");
  chart.setAttribute("aria-valuemax", String(state.run.ticks - 1));
  chart.setAttribute("aria-valuenow", String(current.t));
  chart.setAttribute("aria-valuetext", clock(current.t));
  document.querySelectorAll("#phases button").forEach((button) => {
    const on = button.dataset.phase === current.phase;
    button.classList.toggle("on", on);
    button.setAttribute("aria-pressed", String(on));
  });
  document.querySelectorAll("#speeds button").forEach((button) => {
    const on = Number(button.dataset.speed) === state.speed;
    button.classList.toggle("on", on);
    button.setAttribute("aria-pressed", String(on));
  });
}

function renderChrome(current) {
  const link = $("link-status");
  link.classList.toggle("off", !current.groundLink);
  link.innerHTML = `Ground link: <strong>${current.groundLink ? "available" : "unavailable"}</strong>`;
  const steps = [
    ["shared", "Shared scenario", null],
    ["normal", "Normal operation", "normal"],
    ["hazard", "Radiation rises · ground link lost", "hazard"],
    ["recovery", "Conditions stabilize", "recovery"],
  ];
  $("timeline").innerHTML = steps.map((step, index) => {
    const button = `<button type="button" data-phase="${step[2] || "normal"}" class="${current.phase === step[2] ? "on" : ""}">${esc(step[1])}</button>`;
    const arrow = index === 0 ? "" : `<span class="arrow">→</span>`;
    return arrow + button;
  }).join("");
}

function fluxToRisk(pfu) {
  if (pfu == null || pfu <= 1) return 0;
  const level = Math.log10(pfu);
  const anchors = [[0, 0], [1, 0.22], [2, 0.55], [3, 0.72], [5, 1]];
  if (level >= 5) return 1;
  for (let index = 0; index < anchors.length - 1; index += 1) {
    const [left, leftRisk] = anchors[index];
    const [right, rightRisk] = anchors[index + 1];
    if (level <= right) {
      const span = (level - left) / (right - left);
      return leftRisk + span * (rightRisk - leftRisk);
    }
  }
  return 1;
}

function seriesPath(frames, valueAt, x, y) {
  let path = "";
  let drawing = false;
  frames.forEach((frame, index) => {
    const value = valueAt(frame, index);
    if (value == null || Number.isNaN(value)) {
      drawing = false;
      return;
    }
    path += `${drawing ? "L" : "M"}${x(index).toFixed(1)},${y(value).toFixed(1)} `;
    drawing = true;
  });
  return path;
}

function renderChart() {
  const frames = state.run.frames;
  const width = 1000;
  const height = 92;
  const left = 28;
  const top = 8;
  const plotW = width - left - 8;
  const plotH = 70;
  const x = (t) => left + (t / Math.max(1, frames.length - 1)) * plotW;
  const y = (value) => top + (1 - value) * plotH;
  const noaa = state.run.source === "noaa";
  const bands = frames.filter((item) => !item.groundLink).map((item) =>
    `<rect x="${x(item.t).toFixed(1)}" y="${top}" width="${Math.max(1, plotW / frames.length).toFixed(2)}" height="${plotH}" fill="#ffffff" opacity="0.045"></rect>`
  ).join("");
  const gaps = frames.filter((item) => item.gap).map((item) =>
    `<line x1="${x(item.t).toFixed(1)}" y1="${top}" x2="${x(item.t).toFixed(1)}" y2="${top + plotH}" stroke="#d85a4a" stroke-width="1.2"></line>`
  ).join("");
  const measured = noaa
    ? `<path d="${seriesPath(frames, (frame) => (frame.gap || frame.pfu == null ? null : fluxToRisk(frame.pfu)), x, y)}" fill="none" stroke="#e2b15a" stroke-width="2.2"></path>`
    : "";
  const observed = ["A", "B", "C"].map((node, index) => {
    const color = ["#e2b15a", "#8eb4ff", "#66758c"][index];
    return `<path d="${seriesPath(frames, (frame) => frame.observed ? frame.observed[node] : frame.risk[node], x, y)}" fill="none" stroke="${color}" stroke-width="1.3" stroke-dasharray="4 3"></path>`;
  }).join("");
  const playhead = x(state.t);
  $("chart").innerHTML = `<svg viewBox="0 0 ${width} ${height}" id="spark">
    ${bands}
    ${gaps}
    ${measured}
    ${observed}
    <line x1="${playhead.toFixed(1)}" y1="${top}" x2="${playhead.toFixed(1)}" y2="${top + plotH}" stroke="#f4f7fb" stroke-width="1.2"></line>
  </svg>`;
}

function renderBoard(current) {
  const cards = ORDER.map((name) => {
    const column = current.controllers[name];
    const nodes = column.nodes.map((node) => `<div class="node">
      <b>Node ${esc(node.id)}</b>
      <div class="mode ${node.tone}">${esc(node.label)}</div>
      <div class="sub">risk ${node.risk.toFixed(2)} · ${node.correctable} corr · ${node.uncorrectable} uncorr · ${esc(node.jobs.join(", ") || "idle")} · ${esc(node.health)} simulated</div>
    </div>`).join("");
    return `<article class="card"><h2>${esc(NAMES[name])}</h2>${nodes}<p class="note">${esc(column.note)}</p></article>`;
  }).join("");
  return `<section class="board">${cards}</section>`;
}

function renderLower(current) {
  const metrics = ORDER.map((name) => current.controllers[name].metrics);
  const rows = [
    ["Emergency comms deadlines missed", metrics.map((item) => String(item.criticalMissed)), "min"],
    ["Imagery and flood-map deliveries missed", metrics.map((item) => String(item.missed - item.criticalMissed)), "min"],
    ["Responder-facing service downtime", metrics.map((item) => formatDuration(item.downtime)), "min"],
    ["Lost computation", metrics.map((item) => item.lost.toFixed(1)), "min"],
    ["Essential-service availability", metrics.map((item) => `${(item.availability * 100).toFixed(1)}%`), "max"],
    ["Mean time to restore service", metrics.map((item) => formatDuration(item.recovery)), "min"],
    ["Hardware interlocks", metrics.map((item) => String(item.interlocks)), "min"],
    ["Active steps at risk ≥ 0.45", metrics.map((item) => String(item.exposed)), "min"],
    ["Completed useful work", metrics.map((item) => item.useful.toFixed(0)), "max"],
    ["Best-effort work", metrics.map((item) => item.batch.toFixed(0)), null],
    ["Checkpoint / transfer overhead", metrics.map((item) => formatDuration(item.overhead)), null],
  ];
  const short = { ground: "Ground", threshold: "Fixed", adaptive: "Coop" };
  const head = ORDER.map((name) => `<th>${short[name]}</th>`).join("");
  const body = rows.map(([label, values, goal]) => {
    const numeric = values.map((value) => Number(String(value).replace("%", "")));
    const finite = numeric.filter((value) => !Number.isNaN(value));
    const target = goal === "max" ? Math.max(...finite) : Math.min(...finite);
    const cells = values.map((value, index) => {
      const mark = goal && !Number.isNaN(numeric[index]) && numeric[index] === target && new Set(finite).size > 1;
      return `<td class="${mark ? "best" : ""}">${esc(value)}</td>`;
    }).join("");
    return `<tr><td>${esc(label)}</td>${cells}</tr>`;
  }).join("");
  const decision = current.decision;
  const source = !decision
    ? "Waiting for the hazard trigger."
    : decision.source === "grok"
      ? "Grok"
      : decision.source === "openai"
        ? "OpenAI backup"
        : "Deterministic onboard policy";
  const log = (state.run.log || []).filter((entry) => entry.t <= current.t).slice(-5);
  const logHtml = log.map((entry) => {
    const stamp = state.run.frames[entry.t] && state.run.frames[entry.t].utc;
    const when = stamp ? stamp.slice(5, 16).replace("T", " ") : `t=${entry.t}s`;
    return `<li>${esc(when)} · ${esc(NAMES[entry.controller])}: ${esc(entry.text)}</li>`;
  }).join("");
  const latency = decision && decision.latencyMs != null ? ` · ${decision.latencyMs} ms` : "";
  return `<section class="lower">
    <article class="card inspector">
      <h2>Decision inspector · Cooperative adaptive</h2>
      <p class="source">${esc(source)}${esc(latency)}</p>
      <p><strong>Evidence</strong><span>${esc(decision ? decision.evidence : "Nodes are in normal operation.")}</span></p>
      <p><strong>Proposed action</strong><span>${esc(decision ? decision.action : "No protective action yet.")}</span></p>
      <p><strong>Validation</strong><span>${esc(decision ? decision.validation : "Emergency limits remain in force for every controller.")}</span></p>
      <ol class="log">${logHtml}</ol>
    </article>
    <article class="card">
      <h2>Outcome comparison</h2>
      <table><thead><tr><th>Simulator, ${current.utc ? esc(current.utc.slice(0, 16).replace("T", " ") + " UTC") : clock(current.t)}</th>${head}</tr></thead><tbody>${body}</tbody></table>
    </article>
  </section>`;
}

function stop() {
  state.playing = false;
  if (state.timer) clearInterval(state.timer);
  state.timer = null;
}

function play() {
  if (!state.run) return;
  if (state.playing) {
    stop();
    render();
    return;
  }
  state.playing = true;
  state.timer = setInterval(() => {
    if (state.t >= state.run.ticks - 1) {
      stop();
      render();
      return;
    }
    state.t += 1;
    render();
  }, 1000 / state.speed);
  render();
}

function seekPhase(phase) {
  if (!state.run) return;
  state.t = state.run.phases[phase] ?? 0;
  render();
}

function seekRatio(ratio) {
  if (!state.run) return;
  state.t = Math.round(Math.max(0, Math.min(1, ratio)) * (state.run.ticks - 1));
  render();
}

$("play").addEventListener("click", play);
$("phases").addEventListener("click", (event) => {
  const phase = event.target.dataset.phase;
  if (phase) seekPhase(phase);
});
$("timeline").addEventListener("click", (event) => {
  const phase = event.target.dataset.phase;
  if (phase) seekPhase(phase);
});
$("speeds").addEventListener("click", (event) => {
  const speed = Number(event.target.dataset.speed);
  if (!speed) return;
  state.speed = speed;
  if (state.playing) {
    stop();
    play();
  } else {
    render();
  }
});
$("chart").addEventListener("click", (event) => {
  const svg = event.target.closest("svg");
  if (!svg) return;
  const rect = svg.getBoundingClientRect();
  const ratio = (event.clientX - rect.left) / rect.width;
  seekRatio(ratio);
});
$("chart").addEventListener("keydown", (event) => {
  if (!state.run) return;
  if (event.key === "ArrowRight") seekRatio((state.t + 1) / (state.run.ticks - 1));
  else if (event.key === "ArrowLeft") seekRatio((state.t - 1) / (state.run.ticks - 1));
  else if (event.key === "Home") seekRatio(0);
  else if (event.key === "End") seekRatio(1);
  else return;
  event.preventDefault();
});

const TAB_NAMES = ["overview", "dashboard"];

function applyTab(name) {
  const dashboard = name === "dashboard";
  document.documentElement.dataset.tab = dashboard ? "dashboard" : "overview";
  $("panel-overview").hidden = dashboard;
  $("panel-dashboard").hidden = !dashboard;
  $("tab-overview").setAttribute("aria-selected", String(!dashboard));
  $("tab-dashboard").setAttribute("aria-selected", String(dashboard));
  $("tab-overview").tabIndex = dashboard ? -1 : 0;
  $("tab-dashboard").tabIndex = dashboard ? 0 : -1;
}

function selectTab(name) {
  const next = name === "dashboard" ? "dashboard" : "overview";
  const hash = `#${next}`;
  if (location.hash !== hash) location.hash = hash;
  else applyTab(next);
}

$("site-tabs").addEventListener("click", (event) => {
  const tab = event.target.closest("[role='tab']");
  if (!tab) return;
  selectTab(tab.id === "tab-dashboard" ? "dashboard" : "overview");
});

$("site-tabs").addEventListener("keydown", (event) => {
  const current = location.hash === "#dashboard" ? 1 : 0;
  let next = null;
  if (event.key === "ArrowRight" || event.key === "ArrowDown") next = (current + 1) % 2;
  if (event.key === "ArrowLeft" || event.key === "ArrowUp") next = (current + TAB_NAMES.length - 1) % TAB_NAMES.length;
  if (event.key === "Home") next = 0;
  if (event.key === "End") next = 1;
  if (next == null) return;
  event.preventDefault();
  selectTab(TAB_NAMES[next]);
  $(next === 1 ? "tab-dashboard" : "tab-overview").focus();
});

$("explore").addEventListener("click", () => {
  setTimeout(() => $("dash-title").focus(), 0);
});

window.addEventListener("hashchange", () => {
  applyTab(location.hash === "#dashboard" ? "dashboard" : "overview");
});

applyTab(location.hash === "#dashboard" ? "dashboard" : "overview");

let sliderTimer = null;
function schedule() {
  syncOutputs();
  clearTimeout(sliderTimer);
  sliderTimer = setTimeout(loadRun, 200);
}
["intensity", "outage", "bandwidth", "peer"].forEach((id) => $(id).addEventListener("input", schedule));
function formatDuration(value) {
  const steps = Math.round(Number(value) * 10) / 10;
  const minutes = state.run && state.run.stepMinutes > 1 ? Math.round(steps * state.run.stepMinutes) : null;
  if (minutes == null) return `${steps}s`;
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  return rest ? `${hours}h ${rest}m` : `${hours}h`;
}

function formatPfu(value) {
  const number = Number(value);
  if (number >= 100) return Math.round(number).toLocaleString("en-US");
  return number.toFixed(number >= 10 ? 0 : 2);
}

function renderKey() {
  const key = $("chart-key");
  if (state.run && state.run.source === "noaa") {
    key.innerHTML = `<span class="swatch a"></span> Measured GOES-18 channel sum, mapped onto the simulator scale <span class="swatch b"></span> Simulated local readings: A dashed gold, B dashed blue, C dashed grey <span class="swatch band"></span> Ground outage. A red tick is a missing sample.`;
    return;
  }
  key.innerHTML = `<span class="swatch a"></span> Node A <span class="swatch b"></span> Node B <span class="swatch c"></span> Node C <span class="swatch band"></span> Ground link down. This trace is the scripted risk, not a NOAA record.`;
}

function renderMission() {
  const box = $("mission");
  const mission = state.run && state.run.mission;
  if (!mission || !mission.headline) {
    box.hidden = true;
    box.innerHTML = "";
    return;
  }
  const timeline = (mission.timeline || []).map(([when, what]) =>
    `${esc(when.slice(5, 16).replace("T", " "))} UTC ${esc(what)}`
  ).join(" · ");
  const sources = (mission.sources || []).map(([label, url]) => `<a href="${esc(url)}">${esc(label)}</a>`).join(", ");
  box.hidden = false;
  box.innerHTML = `<h2>${esc(mission.headline)}</h2>
    <p>${esc(mission.context)}</p>
    ${timeline ? `<p class="muted">${timeline}</p>` : ""}
    <p class="muted">${esc(mission.whatIf)}${sources ? ` Sources: ${sources}.` : ""}</p>`;
}

function renderCatalog() {
  const box = $("catalog");
  const replay = state.run && state.run.replay;
  if (!replay) {
    box.hidden = true;
    box.innerHTML = "";
    return;
  }
  const rows = (state.run.catalog || []).map((item) => {
    const flags = `valid ${item.valid == null ? "—" : item.valid}/300 · dead-time ${item.dtc || 0} · out-of-band ${item.oob || 0} · dynamic error ${item.err || 0}`;
    return `<tr><td>${esc(item.utc.replace("T", " ").replace("Z", " UTC"))}</td><td>${esc(item.scale)} · ${formatPfu(item.pfu)} pfu</td><td>${formatPfu(item.extractedPfu)} pfu</td><td>${esc(flags)}</td></tr>`;
  }).join("");
  const body = rows
    ? `<table><thead><tr><th>Catalog time</th><th>NOAA catalog</th><th>GOES-18 channel sum</th><th>Quality flags at that sample</th></tr></thead><tbody>${rows}</tbody></table>`
    : `<p>No catalog peak. Window maximum is ${formatPfu(replay.peakPfu)} pfu at ${esc(replay.peakUtc.replace("T", " ").replace("Z", " UTC"))}, below the S1 threshold of 10 pfu.</p>`;
  box.hidden = false;
  box.innerHTML = `<h2>Catalog check · ${esc(replay.label)}</h2><p>${esc(replay.why)} ${esc(replay.method)}</p>${body}`;
}

function renderSource() {
  const line = $("source-line");
  const replay = state.run && state.run.replay;
  if (!line) return;
  if (!replay) {
    line.textContent = "Scripted hazard. The curves are not a NOAA record.";
    return;
  }
  line.innerHTML = `${esc(replay.satellite)} ${esc(replay.product)} · ${esc(replay.units)} · five-minute steps · <a href="${esc(replay.sourceUrl)}">NOAA/NCEI GOES source</a>`;
}

function riskColor(risk) {
  if (risk >= 0.72) return "#d85a4a";
  if (risk >= 0.55) return "#e2b15a";
  if (risk >= 0.35) return "#8eb4ff";
  return "#3dce86";
}

let capCells = null;

function magneticLatitude(lat, lon) {
  const rad = Math.PI / 180;
  const poleLat = 80.7 * rad;
  const poleLon = -72.7 * rad;
  const value = Math.sin(lat * rad) * Math.sin(poleLat) + Math.cos(lat * rad) * Math.cos(poleLat) * Math.cos(lon * rad - poleLon);
  return Math.asin(Math.max(-1, Math.min(1, value))) / rad;
}

function capMask() {
  if (capCells) return capCells;
  const cells = [];
  for (let lat = -88; lat <= 88; lat += 4) {
    for (let lon = -178; lon <= 178; lon += 4) {
      const mlat = Math.abs(magneticLatitude(lat, lon));
      if (mlat >= 55) cells.push([lon, lat, mlat >= 63 ? 0.28 : 0.12]);
    }
  }
  capCells = cells;
  return cells;
}

function renderOrbitMap(frame) {
  const svg = $("storm");
  const x = (lon) => ((lon + 180) / 360) * 280;
  const y = (lat) => ((90 - lat) / 180) * 140 + 4;
  const flux = frame.pfu == null ? 0 : fluxToRisk(frame.pfu);
  const caps = capMask().map(([lon, lat, alpha]) =>
    `<rect x="${x(lon - 2).toFixed(1)}" y="${y(lat + 2).toFixed(1)}" width="3.2" height="3.2" fill="#e2b15a" opacity="${(alpha * (0.9 + 1.5 * flux)).toFixed(2)}"></rect>`
  ).join("");
  const colors = { A: "#e2b15a", B: "#8eb4ff", C: "#b9c4d4" };
  const start = Math.max(0, frame.t - 18);
  const trails = ["A", "B", "C"].map((node) => {
    const dots = state.run.frames.slice(start, frame.t).map((item) => {
      const pos = item.orbit && item.orbit[node];
      return pos ? `<circle cx="${x(pos.lon).toFixed(1)}" cy="${y(pos.lat).toFixed(1)}" r="1.1" fill="${colors[node]}" opacity="0.5"></circle>` : "";
    }).join("");
    const pos = frame.orbit[node];
    const hot = pos.exposure > 0.5;
    return `${dots}<circle cx="${x(pos.lon).toFixed(1)}" cy="${y(pos.lat).toFixed(1)}" r="${hot ? 5 : 4}" fill="${colors[node]}" stroke="${hot ? "#d85a4a" : "#12161e"}" stroke-width="1.6"></circle>
      <text x="${(x(pos.lon) + 6).toFixed(1)}" y="${(y(pos.lat) + 3).toFixed(1)}" fill="#e7eef8" font-size="9" font-weight="700">${node}</text>`;
  }).join("");
  svg.innerHTML = `<rect x="0" y="4" width="280" height="140" fill="#0c1422" stroke="rgba(186,206,232,0.16)"></rect>
    <line x1="0" y1="${y(0)}" x2="280" y2="${y(0)}" stroke="rgba(186,206,232,0.12)" stroke-dasharray="2 3"></line>
    ${caps}${trails}
    <text x="4" y="156" fill="#93a3b8" font-size="9">Shaded: polar caps where protons reach LEO</text>`;
  const note = $("storm-note");
  const exposure = ["A", "B", "C"].map((node) => `${node} ${(frame.orbit[node].exposure * 100).toFixed(0)}%`).join(" · ");
  if (note) note.textContent = `Exposure this step: ${exposure}. Schematic tilted-dipole shielding, not a rigidity-cutoff model.`;
  $("storm-kicker").textContent = "Ground track";
}

function renderStorm(frame) {
  const svg = $("storm");
  if (!svg) return;
  if (frame.orbit) {
    renderOrbitMap(frame);
    return;
  }
  $("storm-kicker").textContent = "Schematic";
  const progress = frame.gap
    ? 0.15
    : frame.pfu != null
      ? Math.max(0.08, Math.min(1, fluxToRisk(frame.pfu)))
      : Math.max(...Object.values(frame.risk || { A: 0 }));
  const front = 78 + progress * 150;
  const dots = [0, 1, 2, 3, 4, 5].map((index) => {
    const x = 36 + ((front - 36) * (index + 1)) / 6;
    const y = index % 2 === 0 ? 68 : 92;
    return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${index === 5 ? 3.2 : 2}" fill="#e2b15a" opacity="${(0.35 + index * 0.1).toFixed(2)}"></circle>`;
  }).join("");
  svg.innerHTML = `
    <circle cx="36" cy="80" r="18" fill="#e2b15a"></circle>
    <circle cx="36" cy="80" r="28" fill="none" stroke="#e2b15a" opacity="0.35"></circle>
    ${dots}
    <text x="24" y="148" fill="#93a3b8" font-size="11">Sun</text>
    <text x="${Math.min(front, 210).toFixed(0)}" y="28" fill="#e7eef8" font-size="11">${frame.gap ? "gap" : "front"}</text>`;
  const note = $("storm-note");
  if (note) {
    note.textContent = frame.gap
      ? "Measurement missing at this step. The particle front is a schematic, not Sun-to-satellite travel time."
      : "Schematic. Particle position tracks replay flux. It is not Sun-to-satellite travel time.";
  }
}

function renderGraph(frame) {
  const svg = $("graph");
  if (!svg) return;
  const places = { A: [150, 78], B: [470, 78], C: [310, 210] };
  const column = frame.controllers.adaptive.nodes;
  const deliveries = (frame.trace && frame.trace.deliveries) || [];
  const migrating = column.some((node) => node.label === "Receiving jobs" || node.label === "Draining");
  const edges = [["A", "B"], ["B", "C"], ["A", "C"]].map(([left, right]) => {
    const [x1, y1] = places[left];
    const [x2, y2] = places[right];
    const live = deliveries.some((item) => (
      (item.sender === left && item.receiver === right) || (item.sender === right && item.receiver === left)
    ));
    const midX = (x1 + x2) / 2;
    const midY = (y1 + y2) / 2;
    return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${live ? "#e2b15a" : "#8eb4ff"}" stroke-width="${live ? 2.4 : 1.2}" opacity="${live ? 0.95 : 0.45}"></line>
      ${live ? `<circle cx="${midX}" cy="${midY}" r="5" fill="#e2b15a"></circle>` : ""}
      ${migrating ? `<circle cx="${midX}" cy="${midY + 12}" r="3" fill="#3dce86"></circle>` : ""}`;
  }).join("");
  const nodes = column.map((node) => {
    const [x, y] = places[node.id];
    const selected = state.selected === node.id;
    const jobs = node.jobs.length ? node.jobs.join(", ") : "idle";
    return `<g class="sat" tabindex="0" role="button" aria-pressed="${selected}" aria-label="Satellite ${node.id}, ${node.label}, simulated risk ${node.risk.toFixed(2)}" data-node="${node.id}">
      <circle cx="${x}" cy="${y}" r="${selected ? 34 : 30}" fill="${riskColor(node.risk)}" opacity="0.9" stroke="${selected ? "#f4f7fb" : "transparent"}" stroke-width="3"></circle>
      <text x="${x}" y="${y - 2}" text-anchor="middle" fill="#12161e" font-size="16" font-weight="700">${node.id}</text>
      <text x="${x}" y="${y + 14}" text-anchor="middle" fill="#12161e" font-size="9">${esc(node.label)}</text>
      <text x="${x}" y="${y + 48}" text-anchor="middle" fill="#e7eef8" font-size="11">${esc(jobs)}</text>
    </g>`;
  }).join("");
  svg.innerHTML = `${edges}${nodes}`;
}

function stepAge(frame, step) {
  const minutes = state.run && state.run.stepMinutes > 1 ? state.run.stepMinutes : 1;
  const delta = (frame.t - step) * minutes;
  if (state.run && state.run.stepMinutes > 1) {
    return delta === 0 ? "this step" : `${delta} min earlier`;
  }
  return `t=${step}`;
}

function renderNodeReadout(frame) {
  const box = $("node-readout");
  if (!box) return;
  const nodeId = state.selected;
  const column = frame.controllers.adaptive.nodes.find((node) => node.id === nodeId);
  const trace = frame.trace || {};
  const inbox = (trace.inbox && trace.inbox[nodeId]) || [];
  const confidence = trace.confidence ? trace.confidence[nodeId] : null;
  const alerts = inbox.map((item) =>
    `from ${item.sender} (${item.kind}), observed ${stepAge(frame, item.obsT)}, delivered ${stepAge(frame, item.deliverT)}, sim risk ${item.risk.toFixed(2)}${item.ambient == null ? "" : `, ambient estimate ${item.ambient.toFixed(2)}`}, confidence ${item.confidence}`
  ).join("; ") || "none delivered";
  const orbit = frame.orbit ? ` Planned-orbit exposure ${(frame.orbit[nodeId].exposure * 100).toFixed(0)}% (${state.run.orbits[nodeId].label}).` : "";
  const errors = trace.telemetry ? ` Correctable errors this step: ${trace.telemetry[nodeId]}.` : "";
  const proposed = (trace.proposed || []).filter((item) => item.node === nodeId);
  const rejected = (trace.rejected || []).filter((item) => item.node === nodeId);
  const advisor = trace.advisor && trace.advisor.proposed && trace.advisor.proposed.node === nodeId ? trace.advisor : null;
  const measured = frame.pfu == null
    ? (frame.gap ? "measurement missing" : "scripted environment")
    : `${formatPfu(frame.pfu)} pfu measured`;
  const proposal = proposed.length
    ? proposed.map((item) => `${item.action}${item.target ? " → " + item.target : ""}`).join(", ")
    : "hold";
  const rejection = rejected.length
    ? rejected.map((item) => `${item.action} rejected: ${item.reason}`).join("; ")
    : "none";
  const advice = advisor
    ? `Grok proposal ${advisor.proposed.action}${advisor.executed ? `, executed ${advisor.executed}` : ""}${advisor.rejected ? `, rejected: ${advisor.rejected}` : ""}. Remote API call emulating onboard advice.`
    : "The deterministic onboard policy decided this step. Ask Grok requests a remote call that emulates onboard advice.";
  box.textContent = `Node ${nodeId} at ${frame.utc ? frame.utc.replace("T", " ").replace("Z", " UTC") : "t=" + frame.t}: fused local risk ${column.risk.toFixed(2)} (${column.label}, ${column.health}).${orbit}${errors} Shared input: ${measured}. Sensor confidence ${confidence == null ? "—" : confidence}. Alerts ${nodeId} can use: ${alerts}. Proposed ${proposal}. Rejected: ${rejection}. ${advice}`;
}

$("graph").addEventListener("click", (event) => {
  const node = event.target.closest("[data-node]");
  if (!node) return;
  state.selected = node.dataset.node;
  render();
});
$("graph").addEventListener("keydown", (event) => {
  const node = event.target.closest("[data-node]");
  if (!node || (event.key !== "Enter" && event.key !== " ")) return;
  event.preventDefault();
  state.selected = node.dataset.node;
  render();
});

function applySource() {
  const rows = isNoaa() ? NOAA_PRESETS : SCRIPTED_PRESETS;
  const previous = $("preset").value;
  $("preset").innerHTML = rows.map(([id, label]) => `<option value="${esc(id)}">${esc(label)}</option>`).join("");
  $("preset").value = rows.some(([id]) => id === previous) ? previous : (isNoaa() ? "oct2024" : rows[0][0]);
  const selected = rows.find(([id]) => id === $("preset").value);
  const outage = $("outage");
  $("intensity").disabled = isNoaa();
  if (isNoaa()) {
    outage.min = "0";
    outage.max = "72";
    outage.step = "6";
    $("outage-label").textContent = "Ground outage";
  } else {
    outage.min = "0";
    outage.max = "140";
    outage.step = "5";
    $("outage-label").textContent = "Outage duration";
  }
  if (selected) outage.value = selected[2];
  syncOutputs();
}

$("source").addEventListener("change", () => {
  applySource();
  loadRun();
});
$("preset").addEventListener("change", () => {
  const rows = isNoaa() ? NOAA_PRESETS : SCRIPTED_PRESETS;
  const row = rows.find(([id]) => id === $("preset").value);
  if (row) $("outage").value = row[2];
  schedule();
});
$("grok").addEventListener("change", loadRun);

syncOutputs();
loadRun();
